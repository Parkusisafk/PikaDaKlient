package com.pikadaklient;

import net.minecraft.class_310;
import net.minecraft.class_642;

public class ServerCheck {
    public static void printServer() {
        class_310 mc = class_310.method_1551();

        // Singleplayer world check
        if (mc.method_1496()) {
            System.out.println("Connected to: Singleplayer");
            return;
        }

        // Multiplayer server check
        class_642 serverInfo = mc.method_1558();
        if (serverInfo != null) {
            System.out.println("Connected to server: " + serverInfo.field_3761);
            System.out.println("Server name: " + serverInfo.field_3752);
        } else {
            System.out.println("Not connected to any server.");
        }
    }
}
