package com.pikadaklient.mixin;

import com.pikadaklient.utils.AbyssRunner;
import com.pikadaklient.utils.AutoClickerUtils;
import com.pikadaklient.utils.AutoMinerUtils;
import com.pikadaklient.window.ProgressTracker;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// We mix into MinecraftClient so we can inject into the client tick
@Mixin(class_310.class)
public class TickMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onClientTick(CallbackInfo ci) {
        class_310 mc = (class_310) (Object) this;

        // Ensure player and world are loaded
        class_746 player = mc.field_1724;
        class_638 world = mc.field_1687;
        if (player == null || world == null) return;

        // Call the AutoClicker tick function
        AutoMinerUtils.tick(mc);
        AbyssRunner.tick(mc);
    }
}
