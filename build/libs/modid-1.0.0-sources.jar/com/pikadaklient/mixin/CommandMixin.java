package com.pikadaklient.mixin;

import com.pikadaklient.utils.AbyssRunner;
import com.pikadaklient.utils.AutoClickerUtils;
import com.pikadaklient.utils.AutoMinerUtils;
import com.pikadaklient.utils.KeyOpenerUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public class CommandMixin {

	// Use @Shadow to access the chatField text input widget
	@Shadow protected class_342 chatField;

	// TARGET: public boolean keyPressed(int keyCode, int scanCode, int modifiers)
	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {

		// Only proceed if the key pressed is ENTER (257) or NUMPAD ENTER (335)
		if (keyCode != GLFW.GLFW_KEY_ENTER && keyCode != GLFW.GLFW_KEY_KP_ENTER) {
			return;
		}

		// Get the text from the chat field
		String chatText = this.chatField.method_1882().trim();
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || chatText.isEmpty()) return;

		// Strip the leading slash if present, for unified command handling
		String message = chatText.startsWith("/") ? chatText.substring(1).trim() : chatText;

		System.out.println("[PikadaClient Debug] KeyPress Mixin running. Processed message: \"" + message + "\"");

		if (message.equalsIgnoreCase("sp")) {
			AutoMinerUtils.start();
			mc.field_1724.method_7353(class_2561.method_43470("§aAutoClicker started."), false);
			mc.method_1507(null);
			cir.setReturnValue(true);
			cir.cancel();
		} else if (message.equalsIgnoreCase("ep")) {
			AutoMinerUtils.stop();
			mc.field_1724.method_7353(class_2561.method_43470("§cAutoClicker stopped."), false);
			mc.method_1507(null);
			cir.setReturnValue(true);
			cir.cancel();
		} else if (message.equalsIgnoreCase("okey")){
			mc.method_1507(null);

			KeyOpenerUtils.start();

			cir.setReturnValue(true);
			cir.cancel();
		} else if (message.equalsIgnoreCase("as") || message.equalsIgnoreCase("sa")){
			mc.method_1507(null);

			AbyssRunner.start(mc);

			cir.setReturnValue(true);
			cir.cancel();
		} else if (message.equalsIgnoreCase("ae") || message.equalsIgnoreCase("ea")){
			mc.method_1507(null);

			AbyssRunner.stop();

			cir.setReturnValue(true);
			cir.cancel();
		}

	}
}