package com.pikadaklient.window;

import com.pikadaklient.SidebarParser;
import com.pikadaklient.utils.AbyssRunner;
import com.pikadaklient.utils.AutoMinerUtils;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_636;

/**
 * AutoManager - 1.21.8 friendly version.
 * - public fields: prestige, ascensions, coins, currentAction
 * - updateX(...) methods that call ProgressTracker setters
 * - ascension flow: send /ascension, poll for chest GUI, check last slot:
 *     - REDSTONE -> parse tooltip for required prestige
 *     - EMERALD  -> click the slot
 */
public class AutoManager {
    // ----- Singleton instance -----
    private static AutoManager INSTANCE;

    // ----- Public state -----
    private volatile int lastHandledSyncId = -1;

    public volatile int prestige = 0;
    public volatile int ascensions = 0;
    public volatile double coins = 0.0;
    public volatile String currentAction = "None";

    private final String initString;

    public AutoManager(String s) {
        this.initString = s;
        INSTANCE = this; // assign singleton on creation
    }

    /** Get the singleton instance */
    public static AutoManager getInstance() {
        return INSTANCE;
    }

    // ----- Internal / static state -----
    private static final AtomicBoolean initialized = new AtomicBoolean(false);
    private static volatile int requiredPrestige = -1; // parsed from tooltip (-1 = not found)

    // pattern to capture numbers like "1,234" from strings containing "Prestige"
    private static final Pattern PRESTIGE_PATTERN = Pattern.compile("Prestige\\D*([\\d,]+)", Pattern.CASE_INSENSITIVE);



    /** Initialize and run the sequence (safe to call once). */
    public void initialize() {
        if (!initialized.compareAndSet(false, true)) return;
        ProgressTracker tracker = ProgressTracker.getInstance();
        tracker.initWindow();

        // if called with "sp" set ProgressTracker state and local state if desired
        if ("sp".equalsIgnoreCase(initString)) {
            this.currentAction = "prestigegrind";
            tracker.setCurrentState("prestigegrind");
        } else if("sa".equalsIgnoreCase(initString) || "as".equalsIgnoreCase(initString)){
            this.currentAction = "abyssgrind";
            tracker.setCurrentState("abyssgrind");
        }

        try {
            // if player is within the target coords, run transfer sequence then ascension flow
            if (AutoMinerUtils.isPlayerWithin(-1719, 80, -22)) {
                AutoMinerUtils.stop();

                CompletableFuture<Boolean> fut = AutoMinerUtils.runTransferSequenceAsync();
                fut.thenAccept(success -> {
                    if (Boolean.TRUE.equals(success)) {
                        runAscensionSequence();

                        TransferCompleted(initString);


                    } else {
                        System.out.println("[AutoManager] transfer sequence returned false.");
                    }
                });
            } else {
                runAscensionSequence();

                TransferCompleted(initString);


            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public String getInitString() {
        return initString;
    }

    /** Returns parsed required prestige or -1 if not found yet. */
    public static int getRequiredPrestige() {
        return requiredPrestige;
    }

    /** Setter so TooltipUtils or the parser can set it if needed. */
    public static void setRequiredPrestige(int v) {
        requiredPrestige = v;
        ProgressTracker.getInstance().setRequiredPrestige(v);
    }
    private Thread sidebarThread;

    public void startSidebarThread() {
        // Stop previous thread if running
        if (sidebarThread != null && sidebarThread.isAlive()) {
            sidebarThread.interrupt();
        }

        sidebarThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) { // check interruption
                try {
                    Thread.sleep(5000);

                    SidebarParser.SidebarData data = SidebarParser.parse();
                    if (data != null) {
                        if (data.prestige > 0) updatePrestige(data.prestige);
                        if (data.ascension > 0) updateAscension(data.ascension);
                        if (data.coins > 0) updateCoins(data.coins);
                        if (data.rebirth > 0) System.out.println("Rebirth: " + data.rebirth);
                    }

                } catch (InterruptedException e) {
                    System.out.println("[AutoManager] Sidebar thread interrupted.");
                    return; // exit thread
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, "Sidebar-Update-Thread");

        sidebarThread.start();
    }
    public void TransferCompleted(String com){

        AutoMinerUtils.stop();
        AbyssRunner.stop();
        startSidebarThread();

        //main init code goes here


        if ("sp".equalsIgnoreCase(com)) {
            this.currentAction = "prestigegrind";
            ProgressTracker.getInstance().setCurrentState("prestigegrind");
            AutoMinerUtils.start();
        } else if("sa".equalsIgnoreCase(initString) || "as".equalsIgnoreCase(initString)){
            this.currentAction = "abyssgrind";
            ProgressTracker.getInstance().setCurrentState("abyssgrind");
            AbyssRunner.start(class_310.method_1551());
        }
    }
    // ---------------------------
    // Public update methods (also update ProgressTracker)
    // ---------------------------
    public void updatePrestige(int value) {
        this.prestige = value;
        ProgressTracker.getInstance().setPrestige(value);
        if(value >= requiredPrestige){
            runAscensionSequence();

            new Thread(() -> {
                try{
                    Thread.sleep(7500);
                    runAscensionSequence();
                } catch(InterruptedException e){
                    System.out.println(e);
                }
            }).start();
        }
    }

    public void updateAscension(int value) {
        this.ascensions = value;
        ProgressTracker.getInstance().setAscension(value);
    }

    public void updateCoins(int value) {
        this.coins = value;
        ProgressTracker.getInstance().setCoins(value);
    }

    public void updateCurrentAction(String action) {
        if (action == null) action = "None";
        this.currentAction = action;
        ProgressTracker.getInstance().setCurrentAction(action);
    }

    // ---------------------------
    // Ascension sequence: send /ascension, wait for chest GUI, inspect last slot
    // ---------------------------
    private void runAscensionSequence() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) {
            System.out.println("[AutoManager] MinecraftClient or player null.");
            return;
        }

        // 1) send the /ascension command (multiple fallbacks)
        sendChatCommand("/ascension");

        // 2) poll for chest GUI in background thread
        new Thread(() -> {
            final int maxWaitMs = 12_000;
            final int pollIntervalMs = 200;
            int waited = 0;

            while (waited < maxWaitMs) {
                try { Thread.sleep(pollIntervalMs); } catch (InterruptedException ignored) {}
                waited += pollIntervalMs;

                if (!(mc.field_1755 instanceof class_465<?>)) {
                    // not a container GUI — skip
                    continue;
                }
                try { Thread.sleep(1000); } catch (InterruptedException ignored) {}


                class_465<?> screen = (class_465<?>) mc.field_1755;
                class_1703 handler = screen.method_17577();
                if (handler == null) continue;

                int slotCount = handler.field_7761.size();
                if (slotCount <= 0) continue;

// player inventory size (usually 36). Subtract to get the top/container slot count.
                int playerInvSize = 0;
                try {
                    playerInvSize = class_310.method_1551().field_1724.method_31548().method_5439();
                } catch (Throwable t) {
                    // fallback to 36 if anything odd happens
                    playerInvSize = 36;
                }

                int topSlotCount = slotCount - playerInvSize;
                if (topSlotCount <= 0) {
                    System.out.println("[AutoManager] no top/container slots detected (slotCount=" + slotCount + ", playerInvSize=" + playerInvSize + ")");
                    continue;
                }

// last index *within the chest/container portion*
                int lastChestIndex = topSlotCount - 1;

// Find the last useful slot in the chest area (skip empty and filler panes)
                int slotIndex = 51;
                if (slotIndex >= handler.field_7761.size()) {
                    System.out.println("[AutoManager] Slot 51 does not exist in this container.");
                    return;
                }

                class_1735 targetSlot = handler.method_7611(slotIndex);





                if (targetSlot == null) {
                    System.out.println("[AutoManager] no non-empty non-filler slot found in chest area.");
                    return;
                }

                class_1799 stack = targetSlot.method_7677();
                if (stack == null || stack.method_7960()) {
                    System.out.println("[AutoManager] target slot empty after all.");
                    continue;
                }


                System.out.println(String.format("[AutoManager] Chest slot %d => %s | Name: '%s'",
                        slotIndex, stack.method_7909(), stack.method_7964().getString()));

// If REDSTONE -> parse tooltip for required prestige and close the chest after parsing
                if (stack.method_31574(class_1802.field_8725)) {
                    System.out.println("[AutoManager] Found REDSTONE at chest slot " + slotIndex + " -> parsing tooltip...");
                    // parsePrestigeFromTooltipAsync already runs on client thread; it now closes the screen afterwards
                    parsePrestigeFromTooltipAsync(stack, mc);
                    return;
                }

// If EMERALD -> click the slot (on client thread) then close the chest
                if (stack.method_31574(class_1802.field_8687)) {
                    System.out.println("[AutoManager] Found EMERALD at chest slot " + slotIndex + " -> clicking...");
                    // schedule on client thread so handler/click are executed safely
                    mc.execute(() -> {
                        try {
                            clickSlot(handler, slotIndex, mc);
                            updatePrestige(0);
                        } catch (Throwable t) {
                            t.printStackTrace();
                        } finally {
                            // close the screen and allow future handling
                            mc.method_1507(null);
                            lastHandledSyncId = -1;
                        }
                    });
                    return;
                }



// Otherwise log what we found
                System.out.println("[AutoManager] Chest last useful slot contains: " + stack.method_7909() + " | Name: '" + stack.method_7964().getString() + "'");
                return;

            }

            System.out.println("[AutoManager] timed out waiting for chest GUI.");
        }, "AutoManager-AscensionPoll").start();
    }

    // ---------------------------
    // Click helper
    // ---------------------------
    private void clickSlot(class_1703 handler, int slotIndex, class_310 mc) {
        try {
            class_636 im = mc.field_1761;
            if (im != null) {
                int syncId = handler.field_7763;
                im.method_2906(syncId, slotIndex, 0, class_1713.field_7790, mc.field_1724);
                return;
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }

        // fallback via handler.onSlotClick
        try {
            handler.method_7593(slotIndex, 0, class_1713.field_7790, (class_1657) mc.field_1724);
        } catch (Throwable t) {
            t.printStackTrace();
            System.out.println("[AutoManager] failed to click slot - adapt to mappings if necessary.");
        }
    }

    // ---------------------------
    // Tooltip parsing (sync & async variants)
    // ---------------------------

    /**
     * Async-safe: schedules parsing on client thread (mc.execute) and sets requiredPrestige when found.
     * Call this from background threads.
     */
    private void parsePrestigeFromTooltipAsync(class_1799 stack, class_310 mc) {
        if (stack == null || stack.method_7960() || mc == null) return;

        // run on client thread
        mc.execute(() -> {
            try {
                int parsed = parsePrestigeFromTooltipSync(stack, mc);
                if (parsed > 0) {
                    setRequiredPrestige(parsed);
                    System.out.println("[AutoManager] parsed requiredPrestige = " + parsed);
                    if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("§cRequired Prestige: " + parsed), false);
                } else {
                    System.out.println("[AutoManager] no prestige found in tooltip.");
                    // optional: dump tooltip for debugging
                    try {
                        class_9635 ctx = class_9635.method_59528(mc.field_1687);
                        List<class_2561> tt = stack.method_7950(ctx, mc.field_1724, class_1836.field_41070);
                        for (class_2561 line : tt) System.out.println("[AutoManager] TOOLTIP: " + line.getString());
                        //if (stack.) System.out.println("[AutoManager] NBT: " + stack.getNbt());
                    } catch (Throwable ignored) {}
                }
            } catch (Throwable t) {
                t.printStackTrace();
            } finally {
                // Close the chest GUI now that parsing finished, and allow re-processing later
                try {
                    mc.method_1507(null);
                } catch (Throwable ignored) {}
                lastHandledSyncId = -1;
            }
        });
    }


    /**
     * Synchronous tooltip parser. MUST be called on client thread.
     * Returns parsed prestige number, or -1 if not found.
     */
    private int parsePrestigeFromTooltipSync(class_1799 stack, class_310 mc) {
        if (stack == null || stack.method_7960() || mc == null || mc.field_1724 == null || mc.field_1687 == null) return -1;

        // Use a robust pattern to capture the number, allowing any characters (non-greedily)
        // between "Prestige" and the digits/commas. This handles:
        // "Prestige 2,070" and "You must be Prestige 2,070 to ascend!"
        // NOTE: If you only want the *required* prestige, a more targeted pattern is below.
        final Pattern PRESTIGE_PATTERN = Pattern.compile("Prestige.*?([\\d,]+)", Pattern.CASE_INSENSITIVE);

        // Pattern specific to the 'You must be Prestige X to ascend!' line for clarity
        final Pattern REQUIRED_PRESTIGE_PATTERN = Pattern.compile("You must be Prestige\\s*([\\d,]+)", Pattern.CASE_INSENSITIVE);

        try {
            class_9635 context = class_9635.method_59528(mc.field_1687);
            // Using TooltipType.BASIC as in the original, but can be changed if needed
            List<class_2561> tooltip = stack.method_7950(context, mc.field_1724, class_1836.field_41070);

            for (class_2561 line : tooltip) {
                String s = line.getString();
                if (s == null || s.isEmpty()) continue;

                // 1. Check for the specific "You must be" line (most reliable for required prestige)
                Matcher requiredMatcher = REQUIRED_PRESTIGE_PATTERN.matcher(s);
                if (requiredMatcher.find()) {
                    String num = requiredMatcher.group(1);
                    if (num != null) {
                        // This is the number we need, return it immediately
                        String cleaned = num.replaceAll(",", "");
                        try {
                            return Integer.parseInt(cleaned);
                        } catch (NumberFormatException ignored) { }
                    }
                }

                // 2. Fallback to the general PRESTIGE_PATTERN
                // This is less reliable as it could potentially find the "Prestige ➟ 0" line,
                // but is kept as a safeguard if the first line is phrased differently.
                Matcher generalMatcher = PRESTIGE_PATTERN.matcher(s);
                if (generalMatcher.find()) {
                    String num = generalMatcher.group(1);
                    if (num != null) {
                        // Check if this number is 0 (i.e., the current prestige). If so, ignore it.
                        String cleaned = num.replaceAll(",", "");
                        if (!cleaned.equals("0")) {
                            try {
                                // Assume any non-zero prestige number found in the tooltip is the required prestige.
                                return Integer.parseInt(cleaned);
                            } catch (NumberFormatException ignored) { }
                        }
                    }
                }
            }

            // Add fallback: check raw NBT lore if present (as hinted in original code)
            // ... (implementation for NBT parsing would go here) ...

        } catch (Throwable t) {
            t.printStackTrace();
        }

        return -1;
    }

    /** Very small helper to extract "text" from simple JSON text components if present. */
    private static String stripJsonTextComponent(String raw) {
        if (raw == null) return "";
        try {
            java.util.regex.Matcher m = Pattern.compile("\"text\"\\s*:\\s*\"([^\"]+)\"").matcher(raw);
            if (m.find()) return m.group(1);
        } catch (Throwable ignored) {}
        return raw.replaceAll("[{}\"]", "").trim();
    }

    // ---------------------------
    // Chat / command sending helper (multiple fallbacks)
    // ---------------------------
    public static void sendChatCommand(String message) {
        if (message.startsWith("/"))
            class_310.method_1551().field_1724.field_3944.method_45730(message.substring(1));
        else
            class_310.method_1551().field_1724.field_3944.method_45729(message);
    }
}
