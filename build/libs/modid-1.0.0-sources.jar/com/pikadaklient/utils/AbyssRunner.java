package com.pikadaklient.utils;

import com.pikadaklient.window.AutoManager;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

import static com.pikadaklient.utils.AutoMinerUtils.isPlayerWithin;

public class AbyssRunner {
    // --- Configurable constants ---
    private static final class_2338 COORD_A = new class_2338(451, 9, 518);         // first reference coordinate
    private static final int COORD_A_RANGE = 150;                              // within 150 blocks
    private static final class_2338 COORD_B = new class_2338(1028, 35, 1026);      // second reference coordinate
    private static final int COORD_B_RANGE = 5;                                // within 5 blocks for restart condition
    private static final int TIMER_THRESHOLD = 200;                             // timer > 200 triggers restart logic
    private static final long START_WAIT_MS = 15_000L;                         // start() waits 15 seconds
    private static final long GOTO_TIMEOUT_MS = 15_000L;                        // #goto timeout 15 seconds
    private static final double REACH_DISTANCE = 1;                             // considered "arrived" to waypoint
    private static final double HOVER_REACH_THRESHOLD = 0.5;                    // how close to look target before advancing
    private static final double HOVER_LOOK_SPEED = 8.0;                         // degrees per tick interpolation speed (tweak)
    private static final int SCAN_RADIUS = 6;                                   // radius to scan for glazed terracotta
    private static final double VISUAL_MAX_DISTANCE = 4.5;                      // maximum raycast visual distance for hitvecs

    // --- Hardcoded waypoints (replace with your own list) ---
    private static final List<class_2338> WAYPOINTS = Arrays.asList(
            new class_2338(444, 9, 514),
            new class_2338(438, 9, 530),
            new class_2338(432, 12, 526),
            //new BlockPos(429, 14, 518),
            new class_2338(433, 11, 512),
            new class_2338(432, 8, 497),
            new class_2338(427, 8, 477),
            new class_2338(430, 6, 479),
            new class_2338(444, 3, 482),
            new class_2338(455, 3, 475),
            new class_2338(459, 3, 493),
            new class_2338(446, 3, 499)
    );

    // --- Internal state ---
    private static volatile boolean running = false;
    private static int timer = 0;

    private enum NavState { IDLE, WAITING_START, RUNNING, NAVIGATING, HOVERING }
    private static NavState state = NavState.IDLE;

    private static int waypointIndex = 0;
    private static long gotoStartTime = 0L;
    private static class_2338 currentGotoTarget = null;

    // Hovering (chain) state - now uses Vec3d hit vectors
    private static List<class_243> hoverList = new ArrayList<>();
    private static int hoverIndex = 0;
    private static boolean hoveringActive = false;

    // thread-safe guard so we don't call start() many times concurrently
    private static final AtomicBoolean startingGuard = new AtomicBoolean(false);

    public static boolean leftclicking = false;

    // --- Public API ---

    public static void start(class_310 mc) {
        if (startingGuard.getAndSet(true)) return; // already starting
        try {
            if (mc == null || mc.field_1724 == null) {
                startingGuard.set(false);
                return;
            }

            state = NavState.WAITING_START;

            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    sendPlayerMsg("/abyss");
                    Thread.sleep(START_WAIT_MS);
                } catch (InterruptedException ignored) {}
                running = true;
                state = NavState.RUNNING;
                startingGuard.set(false);
            }, "AbyssRunner-Starter").start();
        } finally {
            // nothing
        }
    }

    public static void stop() {
        running = false;
        state = NavState.IDLE;
        timer = 0;
        waypointIndex = 0;
        hoverList.clear();
        hoverIndex = 0;
        hoveringActive = false;
    }

    public static void tick(class_310 mc) {
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
            if (leftclicking) {
                leftclicking = false;
                AHKUtils.stopAHK();
            }
            return;
        }

        if(isPlayerWithin(-1719,80,-22)){
            running = false;
            stop();
            AutoMinerUtils.runTransferSequenceAsync().thenAccept(success -> {
                System.out.println("Transfer success: " + success);

                if (success) {
                    // ✅ Do something if the transfer succeeded
                    start(mc);
                } else {
                    // ❌ Die
                    System.out.println("failed!");
                }
            });
        }

        if (!running && state == NavState.WAITING_START) {
            if (leftclicking) {
                leftclicking = false;
                AHKUtils.stopAHK();
            }
            return;
        }

        if (running && isWithinRange(mc.field_1724.method_19538(), COORD_A, COORD_A_RANGE)) {
            timer++;
        }

        if (running && !isWithinRange(mc.field_1724.method_19538(), COORD_A, COORD_A_RANGE)
                && isWithinRange(mc.field_1724.method_19538(), COORD_B, COORD_B_RANGE)
                && timer > TIMER_THRESHOLD) {
            if (leftclicking) {
                leftclicking = false;
                AHKUtils.stopAHK();
            }
            timer = 0;
            running = false;
            state = NavState.WAITING_START;
            start(mc);
            return;
        }

        if (!running) {
            if (leftclicking) {
                leftclicking = false;
                AHKUtils.stopAHK();
            }
            return;
        }

        if (isWithinRange(mc.field_1724.method_19538(), COORD_A, COORD_A_RANGE)) {
            if (state == NavState.HOVERING && hoveringActive) {
                if (!leftclicking) { leftclicking = true; AHKUtils.startAHK(); }
                processHovering(mc);
                return;
            }

            if (state == NavState.NAVIGATING && currentGotoTarget != null) {
                if(leftclicking){
                    leftclicking = false;
                    AHKUtils.stopAHK();
                }
                double dist = mc.field_1724.method_19538().method_1022(new class_243(currentGotoTarget.method_10263()+0.5, currentGotoTarget.method_10264()+0.5, currentGotoTarget.method_10260()+0.5));
                long now = System.currentTimeMillis();

                if (dist <= REACH_DISTANCE) {
                    state = NavState.RUNNING;
                    currentGotoTarget = null;
                    gotoStartTime = 0;
                    List<class_243> hitVecs = scanVisibleYGTHitVecs(mc, SCAN_RADIUS);
                    if (!hitVecs.isEmpty()) {
                        buildAndStartHoverChainFromHitVecs(mc, hitVecs);
                        //System.out.println("hitVecs: " + hitVecs.size());
                    } else {
                        advanceToNextWaypoint();
                    }
                    return;
                }

                if (now - gotoStartTime > GOTO_TIMEOUT_MS) {
                    currentGotoTarget = null;
                    gotoStartTime = 0;
                    state = NavState.RUNNING;

                    if (!isWithinRange(mc.field_1724.method_19538(), COORD_A, COORD_A_RANGE)
                            && isWithinRange(mc.field_1724.method_19538(), COORD_B, COORD_B_RANGE)
                            && timer > TIMER_THRESHOLD) {
                        timer = 0;
                        running = false;
                        state = NavState.WAITING_START;
                        start(mc);
                        return;
                    } else {
                        advanceToNextWaypoint();
                        return;
                    }
                }

                return;
            }

            if (state == NavState.RUNNING || state == NavState.IDLE) {
                startGotoToWaypoint(mc);
            }
        } else {
            if (isWithinRange(mc.field_1724.method_19538(), COORD_B, COORD_B_RANGE) && timer > TIMER_THRESHOLD) {
                timer = 0;
                running = false;
                state = NavState.WAITING_START;
                start(mc);
            }
        }
    }

    private static void startGotoToWaypoint(class_310 mc) {
        if (WAYPOINTS.isEmpty()) {
            state = NavState.RUNNING;
            return;
        }
        if (waypointIndex >= WAYPOINTS.size()) waypointIndex = 0;
        class_2338 target = WAYPOINTS.get(waypointIndex);
        sendPlayerMsg("#goto " + target.method_10263() + " " + target.method_10264() + " " + target.method_10260());
        currentGotoTarget = target;
        gotoStartTime = System.currentTimeMillis();
        state = NavState.NAVIGATING;
        AutoManager.getInstance().updateCurrentAction(state.toString());

    }

    private static void advanceToNextWaypoint() {
        waypointIndex++;
        if (waypointIndex >= WAYPOINTS.size()) waypointIndex = 0;
        state = NavState.RUNNING;
        AutoManager.getInstance().updateCurrentAction(state.toString());
    }

    /**
     * Improved raytrace-based scan: keep one best hit per (blockPos, face).
     */
    private static List<class_243> scanVisibleYGTHitVecs(class_310 mc, int radius) {
        Map<String, class_243> bestPerFace = new HashMap<>(); // key: "x,y,z:faceIndex"
        if (mc.field_1724 == null || mc.field_1687 == null) return new ArrayList<>();

        class_2338 playerPos = mc.field_1724.method_24515();
        class_243 eyePos = mc.field_1724.method_5836(1.0f);

        double[][] samples = new double[][] {
                {0.2, 0.2}, {0.8, 0.2}, {0.2, 0.8}, {0.8, 0.8}, {0.5, 0.5}, {0.5, 0.2}
        };
        final double INSIDE_EPS = 0.001;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -radius / 2; dy <= radius / 2; dy++) {
                    class_2338 p = playerPos.method_10069(dx, dy, dz);
                    if (!mc.field_1687.method_8393(p.method_10263() >> 4, p.method_10260() >> 4)) continue;

                    class_2680 state = mc.field_1687.method_8320(p);
                    if (state.method_26204() != class_2246.field_10096) continue;

                    for (class_2350 dir : class_2350.values()) {
                        class_2338 neighbor = p.method_10093(dir);
                        class_2680 neighborState = mc.field_1687.method_8320(neighbor);
                        if (!(neighborState.method_26215())) continue;

                        for (double[] uv : samples) {
                            double u = uv[0], v = uv[1];
                            double tx, ty, tz;
                            double bx = p.method_10263(), by = p.method_10264(), bz = p.method_10260();

                            switch (dir) {
                                case field_11034 -> { tx = bx + 1.0 - INSIDE_EPS; ty = by + v;          tz = bz + u; }
                                case field_11039 -> { tx = bx + INSIDE_EPS;      ty = by + v;          tz = bz + u; }
                                case field_11036 ->   { tx = bx + u;               ty = by + 1.0 - INSIDE_EPS; tz = bz + v; }
                                case field_11033 -> { tx = bx + u;               ty = by + INSIDE_EPS; tz = bz + v; }
                                case field_11035 ->{ tx = bx + u;               ty = by + v;          tz = bz + 1.0 - INSIDE_EPS; }
                                case field_11043 ->{ tx = bx + u;               ty = by + v;          tz = bz + INSIDE_EPS; }
                                default ->   { tx = bx + 0.5; ty = by + 0.5; tz = bz + 0.5; }
                            }

                            class_243 target = new class_243(tx, ty, tz);

                            class_3965 result = mc.field_1687.method_17742(new class_3959(
                                    eyePos,
                                    target,
                                    class_3959.class_3960.field_17558,
                                    class_3959.class_242.field_1348,
                                    mc.field_1724
                            ));

                            if (result.method_17783() == class_239.class_240.field_1332 && result.method_17777().equals(p)) {
                                class_243 hitVec = result.method_17784();
                                double dist = eyePos.method_1022(hitVec);
                                if (dist > VISUAL_MAX_DISTANCE) continue;

                                // Key per block pos + face ordinal
                                String key = p.method_10263() + "," + p.method_10264() + "," + p.method_10260() + ":" + dir.ordinal();

                                // Keep the hit that's closest to eye (more visible)
                                class_243 prev = bestPerFace.get(key);
                                if (prev == null || eyePos.method_1022(hitVec) < eyePos.method_1022(prev)) {
                                    bestPerFace.put(key, hitVec);
                                }
                            }
                        }
                    }
                }
            }
        }

        // Collect and sort by distance
        List<class_243> deduped = new ArrayList<>(bestPerFace.values());
        class_243 eyeRef = mc.field_1724.method_5836(1.0f);
        deduped.sort(Comparator.comparingDouble(vec -> eyeRef.method_1022(vec)));

        //System.out.println("RaycastHitVec scan (per-face) found " + deduped.size() + " visible hit points within " + radius + ".");
        return deduped;
    }

    private static void buildAndStartHoverChainFromHitVecs(class_310 mc, List<class_243> hitVecs) {
        class HitPoint {
            final class_243 v;
            final class_2338 pos;
            final class_2350 face;
            HitPoint(class_243 v, class_2338 pos, class_2350 face) { this.v = v; this.pos = pos; this.face = face; }
        }

        List<HitPoint> hpList = new ArrayList<>();
        for (class_243 v : hitVecs) {
            class_2338 p = new class_2338((int)Math.floor(v.field_1352), (int)Math.floor(v.field_1351), (int)Math.floor(v.field_1350));
            double dx = (v.field_1352 - p.method_10263()), dy = (v.field_1351 - p.method_10264()), dz = (v.field_1350 - p.method_10260());

            double diffNorth = Math.abs(dz - 0.0);
            double diffSouth = Math.abs(dz - 1.0);
            double diffWest  = Math.abs(dx - 0.0);
            double diffEast  = Math.abs(dx - 1.0);
            double diffDown  = Math.abs(dy - 0.0);
            double diffUp    = Math.abs(dy - 1.0);

            class_2350 best = class_2350.field_11043;
            double bestDiff = diffNorth;
            if (diffSouth < bestDiff) { best = class_2350.field_11035; bestDiff = diffSouth; }
            if (diffWest  < bestDiff) { best = class_2350.field_11039;  bestDiff = diffWest;  }
            if (diffEast  < bestDiff) { best = class_2350.field_11034;  bestDiff = diffEast;  }
            if (diffDown  < bestDiff) { best = class_2350.field_11033;  bestDiff = diffDown;  }
            if (diffUp    < bestDiff) { best = class_2350.field_11036;    bestDiff = diffUp;    }

            hpList.add(new HitPoint(v, p, best));
        }

        List<HitPoint> remaining = new ArrayList<>(hpList);
        List<class_243> chain = new ArrayList<>();
        if (remaining.isEmpty()) {
            hoverList = chain;
            hoveringActive = false;
            state = NavState.RUNNING;
            return;
        }

        class_243 eye = mc.field_1724.method_5836(1.0f);
        remaining.sort(Comparator.comparingDouble(h -> eye.method_1022(h.v)));
        HitPoint current = remaining.remove(0);
        chain.add(current.v);

        while (!remaining.isEmpty()) {
            HitPoint bestHp = null;
            double bestScore = Double.POSITIVE_INFINITY;

            for (HitPoint cand : remaining) {
                double base;
                if (cand.pos.equals(current.pos) && cand.face == current.face) base = 0.0;
                else if (areAdjacentBlocks(cand.pos, current.pos) && cand.face == current.face) base = 10.0;
                else if (cand.pos.equals(current.pos)) base = 20.0;
                else base = 100.0;

                double dist = current.v.method_1022(cand.v);
                double score = base + dist;
                if (score < bestScore) {
                    bestScore = score;
                    bestHp = cand;
                }
            }

            if (bestHp == null) break;
            chain.add(bestHp.v);
            current = bestHp;
            remaining.remove(bestHp);
        }

        hoverList = chain;
        hoverIndex = 0;
        hoveringActive = true;
        state = NavState.HOVERING;
    }

    private static boolean areAdjacentBlocks(class_2338 a, class_2338 b) {
        int dx = Math.abs(a.method_10263() - b.method_10263());
        int dy = Math.abs(a.method_10264() - b.method_10264());
        int dz = Math.abs(a.method_10260() - b.method_10260());
        return (dx + dy + dz) == 1;
    }

    private static void processHovering(class_310 mc) {
        if (!hoveringActive || hoverList == null || hoverList.isEmpty()) {
            hoveringActive = false;
            state = NavState.RUNNING;
            return;
        }
        if (hoverIndex >= hoverList.size()) {
            hoveringActive = false;
            hoverList.clear();
            hoverIndex = 0;
            advanceToNextWaypoint();
            return;
        }

        class_243 targetVec = hoverList.get(hoverIndex);
        //System.out.println("Hovering to hitVec " + targetVec);

        double eyeX = mc.field_1724.method_19538().field_1352;
        double eyeY = mc.field_1724.method_19538().field_1351 + mc.field_1724.method_18381(mc.field_1724.method_18376());
        double eyeZ = mc.field_1724.method_19538().field_1350;

        float[] targetYawPitch = calcYawPitch(eyeX, eyeY, eyeZ,
                (float) targetVec.field_1352, (float) targetVec.field_1351, (float) targetVec.field_1350);

        float cyaw = mc.field_1724.method_36454();
        float cpitch = mc.field_1724.method_36455();
        float nyaw = approachAngle(cyaw, targetYawPitch[0], (float) HOVER_LOOK_SPEED);
        float npitch = approachAngle(cpitch, targetYawPitch[1], (float) HOVER_LOOK_SPEED);

        mc.field_1724.method_36456(nyaw);
        mc.field_1724.method_36457(npitch);

        float yawDiff = Math.abs(wrapDegrees(nyaw - targetYawPitch[0]));
        float pitchDiff = Math.abs(npitch - targetYawPitch[1]);
        if (yawDiff < 3.0f && pitchDiff < 3.0f) {
            hoverIndex++;
        }
    }

    private static boolean isWithinRange(class_243 pos, class_2338 target, int range) {
        double dx = pos.field_1352 - (target.method_10263() + 0.5);
        double dy = pos.field_1351 - (target.method_10264() + 0.5);
        double dz = pos.field_1350 - (target.method_10260() + 0.5);
        return dx*dx + dy*dy + dz*dz <= (double)range * range;
    }

    private static float[] calcYawPitch(double sx, double sy, double sz, double tx, double ty, double tz) {
        double dx = tx - sx;
        double dy = ty - sy;
        double dz = tz - sz;
        double dist = Math.sqrt(dx*dx + dz*dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, dist)));
        return new float[]{wrapDegrees(yaw), pitch};
    }

    private static float approachAngle(float current, float target, float maxDelta) {
        float diff = wrapDegrees(target - current);
        if (diff > maxDelta) diff = maxDelta;
        if (diff < -maxDelta) diff = -maxDelta;
        return wrapDegrees(current + diff);
    }

    public static void sendPlayerMsg(String message) {
        if (message.startsWith("/"))
            class_310.method_1551().field_1724.field_3944.method_45730(message.substring(1));
        else
            class_310.method_1551().field_1724.field_3944.method_45729(message);
    }

    private static float wrapDegrees(float deg) {
        deg %= 360.0f;
        if (deg >= 180.0f) deg -= 360.0f;
        if (deg < -180.0f) deg += 360.0f;
        return deg;
    }
}
