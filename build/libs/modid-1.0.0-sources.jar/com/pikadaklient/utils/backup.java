package com.pikadaklient.utils;

import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_490;

// NOTE: Ensure your utility file is named AutoWallMinerUtils.java and your Mixins reference this class name.

public class backup {

    private static boolean running = false;
    private static class_2338 targetCornerPos;
    private static int minY = -999;

    // Constants
    private static final int RESET_Y_THRESHOLD = 90;
    private static final int TARGET_SETUP_Y = 88;
    private static final float AIM_PITCH = -30.0f;
    private static final int DESCENT_BLOCKS = 3;
    private static final float TURN_SPEED = 15.0f;
    private static final int TURN_TICKS = 6;

    // State Variables
    private enum State {
        SURFACE_CHECK,
        SETUP_SCANNING,
        SETUP_FLYING,
        SETUP_DESCEND,
        LOOP_MOVE,
        LOOP_TURN,
        LOOP_END,
        DESCEND,
        AFK_RESET
    }
    private static State currentState = State.SURFACE_CHECK;
    private static class_2350 currentDir = class_2350.field_11043;
    private static float turnTargetYaw;
    private static int turnTickCounter;
    private static int turnsCompleted = 0;
    private static double descentYStart = 0;

    public static void start() {
        if (class_310.method_1551().field_1724 == null) return;
        running = true;
        currentState = State.SURFACE_CHECK;
    }

    public static void stop() {
        running = false;
        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1886 != null) mc.field_1690.field_1886.method_23481(false);
        if (mc.field_1690.field_1913 != null) mc.field_1690.field_1913.method_23481(false);
        if (mc.field_1690.field_1832 != null) mc.field_1690.field_1832.method_23481(false);
        if (mc.field_1724 != null) mc.field_1724.method_31549().field_7479 = false;
    }

    public static void tick(class_310 mc) {
        if (!running || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        // --- 0. CAPTCHA HANDLER ---
        if (handleCaptcha(mc)) {
            mc.field_1690.field_1886.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1832.method_23481(false);
            return;
        }

        // --- 1. CORE FUNCTIONALITY: ATTACK ---
        mc.field_1690.field_1886.method_23481(true);
        mc.field_1724.method_6104(class_1268.field_5808);

        // --- 2. STATE MACHINE EXECUTION ---
        switch (currentState) {

            case SURFACE_CHECK:
                if (mc.field_1724.method_23318() >= RESET_Y_THRESHOLD) {
                    mc.field_1724.method_31549().field_7479 = true;
                    mc.field_1724.method_31549().method_7248(0.05f);
                    currentState = State.SETUP_SCANNING;
                    minY = detectMinY(mc);
                } else if (mc.field_1724.method_23318() <= minY + DESCENT_BLOCKS + 1) {
                    currentState = State.AFK_RESET;
                } else {
                    currentState = State.LOOP_MOVE;
                }
                break;

            case SETUP_SCANNING:
                if (findCorner(mc)) {
                    currentState = State.SETUP_FLYING;
                }
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(false);
                break;

            case SETUP_FLYING:
                class_243 targetCenter = class_243.method_24953(targetCornerPos).method_38499(class_2350.class_2351.field_11052, mc.field_1724.method_23318());
                moveTowards(mc, targetCenter, true, false);

                if (mc.field_1724.method_19538().method_1022(targetCenter) < 2.0) {
                    mc.field_1724.method_18799(class_243.field_1353);
                    currentState = State.SETUP_DESCEND;
                }
                break;

            case SETUP_DESCEND:
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(true);

                // FIX: Use the stable method getHorizontalDegreesOrThrow()
                mc.field_1724.method_36456(mc.field_1724.method_36454() + 5.0f);
                mc.field_1724.method_36457(AIM_PITCH);

                if (mc.field_1724.method_23318() <= TARGET_SETUP_Y + 0.5) {
                    mc.field_1690.field_1832.method_23481(false);
                    mc.field_1724.method_18799(class_243.field_1353);
                    turnsCompleted = 0;
                    turnTickCounter = 0;
                    currentState = State.LOOP_MOVE;
                }
                break;

            case LOOP_MOVE:
                mc.field_1690.field_1913.method_23481(true);

                // Corner Detection: Check if horizontal velocity is near zero
                if (mc.field_1724.method_18798().method_37267() < 0.01) {

                    // FIX: Use Direction.fromYaw(float) (this mapping is often stable for converting Yaw to Direction)
                    // If this fails later, we revert to the MathHelper.floor index logic.
// Get player yaw in radians
                    float yawRad = (float) Math.toRadians(mc.field_1724.method_36454());

// Compute left offset (perpendicular)
                    int offsetX = class_3532.method_15357(Math.cos(yawRad + Math.PI / 2)); // left X
                    int offsetZ = class_3532.method_15357(Math.sin(yawRad + Math.PI / 2)); // left Z

                    class_2338 leftPos = mc.field_1724.method_24515().method_10069(offsetX, 0, offsetZ);
                    if(isBedrock(mc.field_1687.method_8320(leftPos))) {
                        mc.field_1690.field_1913.method_23481(false);
                        turnTargetYaw = mc.field_1724.method_36454() + 90.0f; // Turn right (clockwise)
                        turnTargetYaw %= 360;
                        turnTickCounter = 0;
                        currentState = State.LOOP_TURN;
                    }
                }
                break;

            case LOOP_TURN:
                float currentYaw = mc.field_1724.method_36454();
                float yawDiff = turnTargetYaw - currentYaw;

                while (yawDiff < -180) yawDiff += 360;
                while (yawDiff > 180) yawDiff -= 360;

                float turnAmount = yawDiff / (TURN_TICKS - turnTickCounter);
                mc.field_1724.method_36456(currentYaw + turnAmount);

                turnTickCounter++;

                if (turnTickCounter >= TURN_TICKS) {
                    turnsCompleted++;
                    currentDir = currentDir.method_10170();
                    if (turnsCompleted >= 4) {
                        currentState = State.DESCEND;
                    } else {
                        currentState = State.LOOP_MOVE;
                    }
                }
                mc.field_1690.field_1913.method_23481(false);
                break;

            case DESCEND:
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(true);
                descentYStart = mc.field_1724.method_23318();

                if (mc.field_1724.method_23318() <= descentYStart - DESCENT_BLOCKS) {
                    mc.field_1690.field_1832.method_23481(false);
                    if (mc.field_1724.method_23318() <= minY + 1) {
                        currentState = State.AFK_RESET;
                    } else {
                        turnsCompleted = 0;
                        currentState = State.LOOP_MOVE;
                    }
                }
                break;

            case AFK_RESET:
                mc.field_1690.field_1886.method_23481(true);
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(false);
                mc.field_1724.method_31549().field_7479 = false;

                if (mc.field_1724.method_23318() >= RESET_Y_THRESHOLD) {
                    currentState = State.SURFACE_CHECK;
                }
                break;
        }
    }

    //---------------------------------------------------------
    //                   HELPER METHODS
    //---------------------------------------------------------

    private static boolean findCorner(class_310 mc) {
        class_2338 playerPos = mc.field_1724.method_24515();

        for (int x = playerPos.method_10263() - 50; x < playerPos.method_10263() + 50; x++) {
            for (int z = playerPos.method_10260() - 50; z < playerPos.method_10260() + 50; z++) {
                class_2338 pos = new class_2338(x, TARGET_SETUP_Y, z);
                class_2680 state = mc.field_1687.method_8320(pos);

                if (state.method_26215()) {
                    int airCount = 0;
                    int bedrockCount = 0;

                    for (class_2350 dir : class_2350.class_2353.field_11062) {
                        class_2680 adj = mc.field_1687.method_8320(pos.method_10093(dir));
                        if (adj.method_26215()) airCount++;
                        else if (isBedrock(adj)) bedrockCount++;
                    }

                    if (airCount == 2 && bedrockCount == 2) {
                        targetCornerPos = pos;

                        for (class_2350 dir : class_2350.class_2353.field_11062) {
                            if (isBedrock(mc.field_1687.method_8320(pos.method_10093(dir)))) {
                                currentDir = dir.method_10153();
                                break;
                            }
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void moveTowards(class_310 mc, class_243 target, boolean flyXZ, boolean flyY) {
        class_243 dir = target.method_1020(mc.field_1724.method_19538());
        double distance = dir.method_1033();

        if (distance < 0.1) {
            mc.field_1724.method_18799(class_243.field_1353);
            return;
        }

        double speed = mc.field_1724.method_31549().method_7252() * 5.0;

        class_243 movementVec = new class_243(flyXZ ? dir.method_10216() : 0,
                flyY ? dir.method_10214() : 0,
                flyXZ ? dir.method_10215() : 0).method_1029().method_1021(speed);

        mc.field_1724.method_18799(movementVec);

        double yawAngle = Math.toDegrees(Math.atan2(-dir.method_10216(), dir.method_10215()));
        mc.field_1724.method_36456((float) yawAngle);
        mc.field_1724.method_36457(0.0f);
    }

    private static int detectMinY(class_310 mc) {
        int y = mc.field_1724.method_24515().method_10264();
        while (y > mc.field_1687.method_31607()) {
            if (isBedrock(mc.field_1687.method_8320(new class_2338((int) mc.field_1724.method_23317(), y - 1, (int) mc.field_1724.method_23321())))) {
                return y;
            }
            y--;
        }
        return mc.field_1687.method_31607();
    }

    private static boolean handleCaptcha(class_310 mc) {
        if (!(mc.field_1755 instanceof class_465<?> screen) || (screen instanceof class_490)) {
            return false;
        }

        class_1735 targetSlot = null;
        for (class_1735 slot : screen.method_17577().field_7761) {
            class_1799 stack = slot.method_7677();
            if (!stack.method_7960()) {
                String name = stack.method_7964().getString();

                if (name.contains("Click me") || name.contains("Continue")) {
                    if (!stack.method_7909().toString().contains("stained_glass_pane")) {
                        targetSlot = slot;
                        break;
                    }
                }
            }
        }

        if (targetSlot != null) {
            mc.field_1761.method_2906(
                    screen.method_17577().field_7763,
                    targetSlot.field_7874,
                    0,
                    class_1713.field_7790,
                    mc.field_1724
            );
        }
        return true;
    }

    private static boolean isBedrock(class_2680 state) {
        return state.method_26204() == class_2246.field_9987;
    }
}