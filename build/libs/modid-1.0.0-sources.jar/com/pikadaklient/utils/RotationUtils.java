package com.pikadaklient.utils;

import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class RotationUtils {
    private RotationUtils() {}

    // Convert a cardinal Direction to the usual Minecraft yaw (degrees)
    // SOUTH = 0, WEST = 90, NORTH = 180, EAST = 270
    public static float dirToYaw(class_2350 d) {
        switch (d) {
            case field_11035: return 0.0f;
            case field_11039:  return 90.0f;
            case field_11043: return 180.0f;
            case field_11034:  return 270.0f;
            default:    return 0.0f;
        }
    }

    // Convert a yaw (degrees) to the nearest cardinal Direction.
    // Uses the classic floor((yaw * 4 / 360) + 0.5) & 3 mapping.
    public static class_2350 yawToDirection(float yaw) {
        int i = class_3532.method_15375((yaw * 4.0F / 360.0F) + 0.5F) & 3;
        switch (i) {
            case 0: return class_2350.field_11035;
            case 1: return class_2350.field_11039;
            case 2: return class_2350.field_11043;
            default: return class_2350.field_11034;
        }
    }

    // Wraps difference into -180..180
    public static float wrapDegrees(float deg) {
        return class_3532.method_15393(deg);
    }

    // Smoothly rotate player yaw toward targetYaw by up to maxDelta degrees this tick
    // (positive maxDelta rotates fastest; small value = slower/smoother)
    public static void smoothTurnYaw(class_310 mc, float targetYaw, float maxDelta) {
        if (mc.field_1724 == null) return;
        float current = mc.field_1724.method_36454();
        float diff = wrapDegrees(targetYaw - current);

        if (Math.abs(diff) <= maxDelta) {
            mc.field_1724.method_36456(targetYaw);
        } else {
            mc.field_1724.method_36456(current + Math.signum(diff) * maxDelta);
        }
    }
}
