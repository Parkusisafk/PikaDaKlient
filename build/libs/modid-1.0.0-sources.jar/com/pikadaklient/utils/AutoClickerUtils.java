package com.pikadaklient.utils;

import net.minecraft.class_1268;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class AutoClickerUtils {

    private static boolean running = false;

    // Call this to start the autoclicker
    public static void start() {
        running = true;
    }

    // Call this to stop the autoclicker
    public static void stop() {
        running = false;
    }

    // Call this every client tick
    public static void tick(class_310 mc) {
        if (!running || mc.field_1724 == null || mc.field_1687 == null) return;

        // Always "hold" the attack key
        mc.field_1690.field_1886.method_23481(true);

        // Also perform the actual attack action (blocks/entities)
        class_239 hit = mc.field_1765;
        if (hit instanceof class_3965 blockHit) {
            mc.field_1761.method_2910(blockHit.method_17777(), blockHit.method_17780());
        } else {
            // Attack entity if target is an entity
            mc.field_1761.method_2918(mc.field_1724, mc.field_1692);
        }

        // Swing the hand visually
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    public static boolean isRunning() {
        return running;
    }
}
