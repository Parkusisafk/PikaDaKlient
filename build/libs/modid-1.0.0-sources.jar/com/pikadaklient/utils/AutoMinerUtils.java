package com.pikadaklient.utils;

import com.pikadaklient.ServerCheck;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_476;

public class AutoMinerUtils {

    private static boolean running = false;
    private static class_2338 targetCornerPos;
    private static int minY = -999;

    // Constants
    private static final int RESET_Y_THRESHOLD = 90;
    private static final int TARGET_SETUP_Y = 88;
    private static final float AIM_PITCH = 50.0f;
    private static final int DESCENT_BLOCKS = 3;
    private static final int TURN_TICKS = 6;

    // State Variables
    private enum State {
        SURFACE_CHECK,
        SETUP_SCANNING,
        SETUP_FLYING,
        SETUP_DESCEND,
        SETUP_TURN,
        LOOP_MOVE,
        LOOP_TURN,
        DESCEND,
        AFK_RESET
    }
    private static State currentState = State.SURFACE_CHECK;
    private static class_2350 currentDir = class_2350.field_11043;
    private static float turnTargetYaw;
    private static int turnTickCounter;
    private static int turnsCompleted = 0;
    private static double descentYStart = 0;
    private static int tickelapsedforsetupmove = 0;

    public static boolean leftClick = false;

    public static void start() {
        if (class_310.method_1551().field_1724 == null) return;
        running = true;
        currentState = State.SURFACE_CHECK;
        System.out.println("[AutoMiner] Started.");
    }

    public static void stop() {
        running = false;
        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1886 != null) mc.field_1690.field_1886.method_23481(false);
        if (mc.field_1690.field_1913 != null) mc.field_1690.field_1913.method_23481(false);
        if (mc.field_1690.field_1832 != null) mc.field_1690.field_1832.method_23481(false);
        if (mc.field_1724 != null) mc.field_1724.method_31549().field_7479 = false;
        AHKUtils.stopAHK();
        System.out.println("[AutoMiner] Stopped.");
    }

    public static void tick(class_310 mc) {
        if (!running || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        ServerCheck.printServer();
        // --- CAPTCHA HANDLER ---
        if (handleCaptcha(mc)) {
            mc.field_1690.field_1886.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1832.method_23481(false);
            return;
        }

        // --- ATTACK ---
        if(currentState != State.SURFACE_CHECK &&
        currentState != State.SETUP_DESCEND &&
        currentState != State.SETUP_FLYING &&
        currentState != State.SETUP_SCANNING &&
        currentState != State.AFK_RESET) {
            //mc.options.attackKey.setPressed(true);
            //performAttack(mc);
        }
        // --- STATE MACHINE ---
        switch (currentState) {

            case SURFACE_CHECK:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.field_1724.method_23318() >= RESET_Y_THRESHOLD) {
                    mc.field_1724.method_31549().field_7479 = true;
                    mc.field_1724.method_31549().method_7248(0.05f);
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_SCANNING;
                    minY = detectMinY(mc);
                    System.out.println("[AutoMiner] Surface detected. MinY=" + minY);
                } else if (mc.field_1724.method_23318() <= 19) { //hardcoded
                    currentState = State.AFK_RESET;
                    System.out.println("[AutoMiner] AFK reset triggered.");
                } else {
                    tickelapsedforsetupmove = 0;
                    currentState = State.LOOP_MOVE;
                }
                break;

            case SETUP_SCANNING:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (findCorner(mc)) {
                    System.out.println("[AutoMiner] Corner found at " + targetCornerPos);
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_FLYING;
                }
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(false);
                break;

            case SETUP_FLYING:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 1000){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (!mc.field_1724.method_31549().field_7479) {
                    // Simulate a jump (spacebar press)
                    mc.field_1690.field_1903.method_23481(true);

                    // Give Minecraft a tick to register the jump
                    // (release immediately so it doesn't spam jump)
                    mc.field_1690.field_1903.method_23481(false);

                    // Enable flying explicitly
                    mc.field_1724.method_31549().field_7479 = true;
                    mc.field_1724.method_31549().method_7248(0.05f);

                    System.out.println("[AutoMiner] Activated flying mode.");
                }
                class_2338 pos = targetCornerPos;
                class_243 targetCenter = new class_243(
                        pos.method_10263() + 0.5, // center X
                        mc.field_1724.method_23318(), // current Y
                        pos.method_10260() + 0.5  // center Z
                );                moveTowards(mc, targetCenter, true, false);
                System.out.println("[AutoMiner] Flying to corner: currentPos=" + mc.field_1724.method_19538());

                if (mc.field_1724.method_19538().method_1022(targetCenter) < 0.3) {
                    mc.field_1724.method_18799(class_243.field_1353);
                    currentState = State.SETUP_DESCEND;
                    tickelapsedforsetupmove = 0;
                    System.out.println("[AutoMiner] Reached corner, descending...");
                }
                break;

            case SETUP_DESCEND:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(true);
                mc.field_1724.method_36457(AIM_PITCH);

                if (mc.field_1724.method_23318() <= TARGET_SETUP_Y - 0.5) {
                    mc.field_1690.field_1832.method_23481(false);
                    mc.field_1724.method_18799(class_243.field_1353);
                    turnsCompleted = 0;
                    turnTickCounter = 0;
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_TURN;
                    System.out.println("[AutoMiner] Setup descend complete. Start mining loop.");
                }
                break;

            case SETUP_TURN:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                // Ensure no stray keys are pressed
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(false);

                class_2338 playerPos = mc.field_1724.method_24515();
                class_2350 chosenDir = null;

                // Find the open direction: the one after two consecutive bedrock blocks clockwise
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    class_2350 clockwise1 = dir;
                    class_2350 clockwise2 = dir.method_10170();

                    boolean b1 = isBedrock(mc.field_1687.method_8320(playerPos.method_10093(clockwise1)));
                    boolean b2 = isBedrock(mc.field_1687.method_8320(playerPos.method_10093(clockwise2)));

                    if (b1 && b2) {
                        // The next clockwise direction is the tunnel direction
                        chosenDir = clockwise2.method_10170();
                        break;
                    }
                }

                if (chosenDir != null) {
                    currentDir = chosenDir;

                    // Look into the mine (perpendicular to wall, inward)
                    class_2350 intoMine = currentDir.method_10160();
                    float baseYaw = RotationUtils.dirToYaw(intoMine);

                    // Apply small left bias
                    float bias = 15.0f; // adjust as needed
                    float targetYaw = (baseYaw + 85) % 360.0f; //HARDCODED GOES HARD AF


                    // Smoothly turn toward target yaw
                    RotationUtils.smoothTurnYaw(mc, targetYaw, 10.0f);

                    // Look downward at ~30°
                    mc.field_1724.method_36457(30.0f);

                    // When close enough to target yaw, move to LOOP_MOVE
                    if (Math.abs(RotationUtils.wrapDegrees(targetYaw - mc.field_1724.method_36454())) < 2.0f) {
                        System.out.println("[AutoMiner] Setup turn complete. Facing " + currentDir);
                        tickelapsedforsetupmove = 0;
                        currentState = State.LOOP_MOVE;
                    }
                } else {
                    System.out.println("[AutoMiner] Could not determine initial tunnel direction!");
                }
                break;

            case LOOP_MOVE:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.field_1724.method_23318() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.field_1724.method_23318() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    mc.field_1690.field_1913.method_23481(true);
                    mc.field_1724.method_36457(AIM_PITCH);
                    //mc.player.setYaw();
                    // Check left wall
                    class_2338 playerPos1 = mc.field_1724.method_24515();
                    class_2350 moveDir = currentDir; // direction we are flying along
                    class_2350 lookDir2 = moveDir.method_10170(); // 90° clockwise from movement = facing inward


// Block behind (wall you’re hugging)
                    class_2338 backPos = playerPos1.method_10093(lookDir2);

// Block to the left (corner detection)
                    class_2338 leftPos = playerPos1.method_10093(moveDir.method_10160());

// Debugging
                    class_2680 backState = mc.field_1687.method_8320(backPos);
                    class_2680 leftState = mc.field_1687.method_8320(leftPos);

                    System.out.println("[AutoMiner] Back block: " + backPos + " Type: " + backState.method_26204().method_63499());
                    System.out.println("[AutoMiner] Left block: " + leftPos + " Type: " + leftState.method_26204().method_63499());

// Turning condition: bedrock to the left
                    if (isBedrock(leftState)) {
                        System.out.println("[AutoMiner] Bedrock detected on left at " + leftPos + ", turning...");
                        mc.field_1690.field_1913.method_23481(false);
                        turnTargetYaw = mc.field_1724.method_36454() + 90.0f;
                        turnTargetYaw %= 360;
                        turnTickCounter = 0;
                        tickelapsedforsetupmove = 0;
                        currentState = State.LOOP_TURN;
                    }
                }
                break;

            case LOOP_TURN:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.field_1724.method_23318() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.field_1724.method_23318() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    float currentYaw = mc.field_1724.method_36454();
                    float yawDiff = turnTargetYaw - currentYaw;
                    while (yawDiff < -180) yawDiff += 360;
                    while (yawDiff > 180) yawDiff -= 360;

                    float turnAmount = yawDiff / (TURN_TICKS - turnTickCounter);
                    mc.field_1724.method_36456(currentYaw + turnAmount);
                    turnTickCounter++;

                    if (turnTickCounter >= TURN_TICKS) {
                        turnsCompleted++;
                        currentDir = currentDir.method_10170();
                        System.out.println("[AutoMiner] Turn completed. Turns done: " + turnsCompleted);
                        if (turnsCompleted >= 2) { //hardcoded
                            tickelapsedforsetupmove = 0;
                            currentState = State.DESCEND;
                            descentYStart = mc.field_1724.method_23318();
                            System.out.println("[AutoMiner] Completed loop, starting descent.");
                        } else {
                            tickelapsedforsetupmove = 0;
                            currentState = State.LOOP_MOVE;
                        }
                    }
                    mc.field_1690.field_1913.method_23481(false);
                }
                break;

            case DESCEND:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.field_1724.method_23318() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.field_1724.method_23318() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    mc.field_1690.field_1913.method_23481(false);
                    mc.field_1690.field_1832.method_23481(true);

                    if (descentYStart == 0) descentYStart = mc.field_1724.method_23318();

                    if (mc.field_1724.method_23318() <= descentYStart - 3) {
                        mc.field_1690.field_1832.method_23481(false);
                        System.out.println("[AutoMiner] Descend complete. CurrentY=" + mc.field_1724.method_23318());
                        if (mc.field_1724.method_23318() <= 20) {
                            tickelapsedforsetupmove = 0;
                            currentState = State.AFK_RESET;
                            System.out.println("[AutoMiner] Reached bottom. AFK reset.");
                        } else {
                            turnsCompleted = 0;
                            tickelapsedforsetupmove = 0;
                            currentState = State.LOOP_MOVE;
                            descentYStart = 0;
                            System.out.println("[AutoMiner] Starting next mining loop.");
                        }
                    }
                }
                break;

            case AFK_RESET:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                //mc.options.attackKey.setPressed(true);
                mc.field_1690.field_1913.method_23481(false);
                mc.field_1690.field_1832.method_23481(false);
                mc.field_1724.method_31549().field_7479 = false;
                if (mc.field_1724.method_23318() >= RESET_Y_THRESHOLD) {
                    currentState = State.SURFACE_CHECK;
                }
                break;
        }
    }

    // ---------------- Helper Methods ----------------


    private static void performAttack(class_310 mc) {
//        if (mc.player == null || mc.interactionManager == null || mc.world == null) return;
//
//        HitResult hit = mc.crosshairTarget;
//        // Keep the attack key pressed. This is required for the client to think it's still mining.
//        mc.options.attackKey.setPressed(true);
//
//        if (hit instanceof BlockHitResult blockHit) {
//            BlockPos pos = blockHit.getBlockPos();
//            Direction side = blockHit.getSide();
//
//            // --- 1. ESTABLISH MINING STATE ---
//            // Call the standard method once per block to send the initial START_DESTROY_BLOCK
//            // and tell the client's interaction manager which block is being broken.
//            // It does not hurt to call this every tick if the block hasn't changed.
//            mc.interactionManager.attackBlock(pos, side);
//
//            // --- 2. INSTABREAK SPAM (The core of InstantRebreak) ---
//            // Aggressively send the STOP_DESTROY_BLOCK packet every tick.
//            // This forces the server to check for block break completion, which is instant
//            // if the player has high Haste/Efficiency.
//            mc.interactionManager.sendSequencedPacket(mc.world, s ->
//                    new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, pos, side, s)
//            );
//
//            // --- 3. VISUAL/SWING ---
//            // You only need to call mc.player.swingHand(Hand.MAIN_HAND) once here.
//            // No need for a separate HandSwingC2SPacket unless you wanted to prevent the visual swing.
//            mc.player.swingHand(Hand.MAIN_HAND);
//e
//        } else if (mc.targetedEntity != null) {
//            // Attack entities if they are the target.
//            mc.interactionManager.attackEntity(mc.player, mc.targetedEntity);
//            mc.player.swingHand(Hand.MAIN_HAND);
//        }
    }


    private static class_2350 findInitialDir(class_2338 pos) {
        class_310 mc = class_310.method_1551();
        // Check all 4 cardinal directions around player
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2680 state = mc.field_1687.method_8320(pos.method_10093(dir));
            System.out.println("[AutoMiner] Check " + dir + ": " + state.method_26204().method_63499());
        }

        // Loop through clockwise order
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2350 cw1 = dir.method_10170();
            class_2350 cw2 = cw1.method_10170();

            boolean firstBedrock = isBedrock(mc.field_1687.method_8320(pos.method_10093(dir)));
            boolean secondBedrock = isBedrock(mc.field_1687.method_8320(pos.method_10093(cw1)));
            boolean thirdOpen = !isBedrock(mc.field_1687.method_8320(pos.method_10093(cw2)));

            if (firstBedrock && secondBedrock && thirdOpen) {
                System.out.println("[AutoMiner] Initial move dir found: " + cw2);
                return cw2; // this is the correct currentDir
            }
        }

        System.out.println("[AutoMiner] Failed to find initial move dir, defaulting to NORTH");
        return class_2350.field_11043; // fallback
    }

    private static boolean findCorner(class_310 mc) {
        class_2338 playerPos = mc.field_1724.method_24515();

        // Define the hardcoded blacklisted coordinate
        final int BLACKLIST_X = 67055;
        final int BLACKLIST_Z = 233104;

        for (int x = playerPos.method_10263() - 50; x < playerPos.method_10263() + 50; x++) {
            for (int z = playerPos.method_10260() - 50; z < playerPos.method_10260() + 50; z++) {

                // NOTE: TARGET_SETUP_Y must be defined outside this method (e.g., as a static final field)
                class_2338 pos = new class_2338(x, TARGET_SETUP_Y, z);

                // --- BLACKLIST CHECK ---
                if (x == BLACKLIST_X || z == BLACKLIST_Z) {
                    System.out.println("[AutoMiner] Skipping blacklisted corner: " + pos + " (Hardcoded exclusion)");
                    continue; // Skip the rest of the loop iteration for this position
                }
                // -----------------------

                class_2680 state = mc.field_1687.method_8320(pos);

                if (state.method_26215()) {
                    int airCount = 0, bedrockCount = 0;

                    for (class_2350 dir : class_2350.class_2353.field_11062) {
                        class_2680 adj = mc.field_1687.method_8320(pos.method_10093(dir));
                        if (adj.method_26215()) airCount++;
                        else if (isBedrock(adj)) bedrockCount++; // Assuming isBedrock is defined elsewhere
                    }

                    // If this position has exactly two air blocks and two bedrock blocks (a perfect corner)
                    if (airCount == 2 && bedrockCount == 2) {
                        targetCornerPos = pos;
                        System.out.println("[AutoMiner] Corner candidate found: " + pos);

                        // Determine the mining direction (opposite the nearest bedrock wall)
                        for (class_2350 dir : class_2350.class_2353.field_11062) {
                            if (isBedrock(mc.field_1687.method_8320(pos.method_10093(dir)))) {
                                currentDir = dir.method_10153();
                                break;
                            }
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private static void moveTowards(class_310 mc, class_243 target, boolean flyXZ, boolean flyY) {
        class_243 dir = target.method_1020(mc.field_1724.method_19538());
        double distance = dir.method_1033();
        if (distance < 0.1) {
            mc.field_1724.method_18799(class_243.field_1353);
            return;
        }
        double speed = mc.field_1724.method_31549().method_7252() * 5.0;
        class_243 movementVec = new class_243(flyXZ ? dir.method_10216() : 0,
                flyY ? dir.method_10214() : 0,
                flyXZ ? dir.method_10215() : 0).method_1029().method_1021(speed);
        mc.field_1724.method_18799(movementVec);
        double yawAngle = Math.toDegrees(Math.atan2(-dir.method_10216(), dir.method_10215()));
        mc.field_1724.method_36456((float) yawAngle);
        mc.field_1724.method_36457(0.0f);
    }
    private static int detectMinY(class_310 mc) {
        int y = mc.field_1724.method_24515().method_10264();
        while (y > mc.field_1687.method_31607()) {
            if (isBedrock(mc.field_1687.method_8320(new class_2338((int) mc.field_1724.method_23317(), y - 1, (int) mc.field_1724.method_23321())))) {
                return y;
            }
            y--;
        }
        return mc.field_1687.method_31607();
    }

    private static boolean handleCaptcha(class_310 mc) {
        if (!(mc.field_1755 instanceof class_476 screen)) {
            return false;
        }

        class_1735 targetSlot = null;

        System.out.println("--- CAPTCHA ITEM DEBUG START ---");

        for (class_1735 slot : screen.method_17577().field_7761) {
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;

            String plainName = stack.method_7964().getString().toLowerCase();
            String itemString = stack.method_7909().toString();

            boolean nameMatch = plainName.contains("click") && (plainName.contains("confirm") || plainName.contains("continue"));
            boolean isFiller = itemString.contains("stained_glass_pane");
            boolean isMatch = nameMatch && !isFiller;

            System.out.printf(
                    "[SLOT %d] Item: %s | Name: '%s' | NameMatch: %b | IsFiller: %b | Final Match: %b%n",
                    slot.field_7874, itemString, plainName, nameMatch, isFiller, isMatch
            );

            if (isMatch) {
                targetSlot = slot;
                break;
            }
        }

        System.out.println("--- CAPTCHA ITEM DEBUG END ---");

        if (targetSlot != null) {
            System.out.printf("[CAPTCHA SUCCESS] Clicking Slot ID: %d%n", targetSlot.field_7874);
            clickSlot(screen, targetSlot.field_7874, false); // use helper, left-click
        } else {
            System.out.println("[CAPTCHA FAIL] No clickable item found.");
        }

        return targetSlot != null;
    }
    private static void clickSlot(class_476 screen, int slot, boolean right) {
         class_310 mc = class_310.method_1551();
         mc.field_1761.method_2906(
                screen.method_17577().field_7763,
                slot,
                right ? 1 : 0,
                class_1713.field_7790,
                mc.field_1724
        );
    }

    private static boolean isBedrock(class_2680 state) {
        return state.method_26204() == class_2246.field_9987;
    }
}
