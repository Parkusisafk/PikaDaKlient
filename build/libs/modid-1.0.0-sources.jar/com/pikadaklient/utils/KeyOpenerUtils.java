package com.pikadaklient.utils;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_476;

public class KeyOpenerUtils {
    private static final class_310 mc = class_310.method_1551();
    private static boolean running = false;
    private static int totalOpened = 0;

    public static void start() {
        running = true;
        loop();
    }

    private static void loop() {
        new Thread(() -> {
            while (running) {
                try {
                    if (!isChestInFront()) {
                        sendChat("No chest detected.");
                        running = false;
                        break;
                    }

                    // Step 1: open chest
                    rightClickChest();

                    // Step 2: wait for GUI
                    waitForGui(class_476.class);
                    Thread.sleep(100);
                    if (!(mc.field_1755 instanceof class_476 chest)) {
                        sendChat("No chest GUI opened.");
                        running = false;
                        break;
                    }

                    // Step 3: check slot 14 (index 13 zero-based)
                    class_1799 hookStack = chest.method_17577().method_7611(13).method_7677();
                    if (hookStack.method_7909() != class_1802.field_8366) {
                        sendChat("No keys found.");

                        tryCloseGui();
                        Thread.sleep(500);
                        continue;
                    }

                    int keysLeft = parseKeys(hookStack);
                    sendChat("Keys remaining: " + keysLeft);

                    if (keysLeft > 6) {
                        // right click on slot 14
                        clickSlot(chest, 13, true);


                        // wait for "Open Multiple" gui
                        waitForTitle("Multiple");

                        // now click slot 13 (6 keys stack)
                        if (mc.field_1755 instanceof class_476 openMultiple) {
                            // now click slot 13 (index 12 zero-based) in this new screen
                            clickSlot(openMultiple, 12, false);
                        }

                        // wait 2s
                        Thread.sleep(2000);

                        // close GUI
                        tryCloseGui();

                        totalOpened += 6;
                    } else {
                        sendChat("Done! Total keys opened: " + totalOpened);
                        running = false;
                        break;
                    }

                    // loop again
                    Thread.sleep(100);

                } catch (Exception e) {
                    e.printStackTrace();
                    running = false;
                }
            }
        }).start();
    }

    private static boolean isChestInFront() {
        if (mc.field_1724 == null) return false;
        class_3965 hit = (class_3965) mc.field_1724.method_5745(4.5, 0, false);
        return mc.field_1687.method_8320(hit.method_17777()).method_26204().method_9518().getString().toLowerCase().contains("chest");
    }

    private static void rightClickChest() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        // Raycast up to 5 blocks ahead
        class_3965 hit = (class_3965) mc.field_1724.method_5745(5.0, 0.0f, false);

        // Only interact if the hit is actually a block
        if (hit.method_17783() == net.minecraft.class_239.class_240.field_1332) {
            mc.field_1761.method_2896(
                    mc.field_1724,
                    class_1268.field_5808,
                    hit
            );
            mc.field_1724.method_6104(class_1268.field_5808);

        }
    }

    private static void waitForGui(Class<?> clazz) throws InterruptedException {
        int timeout = 40;
        while (timeout-- > 0) {
            if (clazz.isInstance(mc.field_1755)) return;
            Thread.sleep(100);
        }
    }

    private static void waitForTitle(String startsWith) throws InterruptedException {
        int timeout = 40;
        while (timeout-- > 0) {
            if (mc.field_1755 != null &&
                    mc.field_1755.method_25440().getString().toLowerCase().contains(startsWith.toLowerCase())) return;
            Thread.sleep(100);
        }
    }

    private static int parseKeys(class_1799 stack) {
        if (stack.method_7960() || mc.field_1724 == null || mc.field_1687 == null) return 0;

        // Build tooltip context from the client world
        class_1792.class_9635 context = class_1792.class_9635.method_59528(mc.field_1687);

        // BASIC = normal tooltip, ADVANCED = with debug info (like F3+H)
        List<class_2561> tooltip = stack.method_7950(
                context,
                mc.field_1724,
                net.minecraft.class_1836.field_41070
        );

        for (class_2561 line : tooltip) {
            String s = line.getString();
            if (s.contains("Currently stored:")) {
                String num = s.replaceAll("[^0-9]", "");
                try {
                    return Integer.parseInt(num);
                } catch (NumberFormatException ignored) {
                    return 0;
                }
            }
        }
        return 0;
    }

    private static void clickSlot(class_476 screen, int slot, boolean right) {
        mc.field_1761.method_2906(
                screen.method_17577().field_7763,
                slot,
                right ? 1 : 0,
                class_1713.field_7790,
                mc.field_1724
        );
    }

    private static void tryCloseGui() throws InterruptedException {
        int tries = 10;
        while (tries-- > 0) {
            if (mc.field_1755 == null) return;
            mc.field_1724.method_7346();
            Thread.sleep(200);
        }
    }

    private static void sendChat(String msg) {
        if (mc.field_1724 != null)
            mc.field_1724.method_7353(class_2561.method_30163(msg), false);
    }
}
