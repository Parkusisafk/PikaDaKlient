package com.pikadaklient;

import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9015;
import net.minecraft.scoreboard.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Deep scoreboard inspector for debugging purposes.
 * Dumps *everything* it can find about objectives, score holders, slots, and values.
 *
 * Compatible with 1.21.8 mappings where:
 * - getAllPlayerScores() no longer exists
 * - ScoreHolder has getDisplayName(), getStyledDisplayName(), getNameForScoreboard()
 * - Scoreboard.getScore(holder, objective) returns a ScoreAccess-like object
 */
public class ScoreboardPrinter {
    private static final class_310 mc = class_310.method_1551();

    public static void dumpEverything() {
        System.out.println("====================== [SCOREBOARD DUMP] ======================");

        if (mc == null) {
            System.out.println("MinecraftClient is null!");
            return;
        }
        if (mc.field_1687 == null) {
            System.out.println("World is null (probably not in a game).");
            return;
        }

        class_269 scoreboard = mc.field_1687.method_8428();
        if (scoreboard == null) {
            System.out.println("Scoreboard is null.");
            return;
        }

        dumpTeams(scoreboard);
        // --- Dump all objectives ---
        Collection<class_266> objectives = scoreboard.method_1151();
        System.out.println("Found " + objectives.size() + " objectives:");
        for (class_266 obj : objectives) {
            dumpObjective(scoreboard, obj);
        }

        // --- Dump display slots ---
        System.out.println("\nDisplay slots:");
        for (class_8646 slot : class_8646.values()) {
            class_266 obj = scoreboard.method_1189(slot);
            if (obj != null) {
                System.out.println("  Slot " + slot + " -> " + safeText(obj.method_1114()) + " [" + obj.method_1113() + "]");
            } else {
                System.out.println("  Slot " + slot + " -> (empty)");
            }
        }

        // --- Dump all known score holders ---
        Collection<class_9015> holders = scoreboard.method_1178();
        System.out.println("\nKnown score holders: " + holders.size());
        for (class_9015 holder : holders) {
            dumpScoreHolder(scoreboard, holder, objectives);
        }

        System.out.println("====================== [END SCOREBOARD DUMP] ======================");
    }


    public static void dumpTeams(class_269 scoreboard) {
        System.out.println("\n====================== [TEAMS DUMP] ======================");
        Collection<class_268> teams = scoreboard.method_1159();
        System.out.println("Found " + teams.size() + " teams:");

        for (class_268 team : teams) {
            String prefix = safeText(team.method_1144());
            String suffix = safeText(team.method_1136());
            String color = team.method_1202().method_537();

            // Get the members of the team. For a sidebar, this is often the invisible ScoreHolder.
            Collection<String> members = team.method_1204();

            System.out.println("\n--- Team: " + team.method_1197() + " ---");
            System.out.println("  Display Name: " + safeText(team.method_1140()));
            System.out.println("  Color: " + color);
            System.out.println("  Prefix: " + (prefix.isEmpty() ? "(empty)" : prefix));
            System.out.println("  Suffix: " + (suffix.isEmpty() ? "(empty)" : suffix));

            if (!members.isEmpty()) {
                System.out.println("  Members (" + members.size() + "):");
                for (String member : members) {
                    System.out.println("    -> " + member);
                }
            }
        }
        System.out.println("====================== [END TEAMS DUMP] ======================");
    }


    private static void dumpObjective(class_269 scoreboard, class_266 obj) {
        System.out.println("\n=== Objective ===");
        System.out.println("Name: " + obj.method_1113());
        System.out.println("Display Name: " + safeText(obj.method_1114()));
        System.out.println("Criterion: " + safeToString(obj.method_1116()));
        System.out.println("Render Type: " + safeToString(obj.method_1118()));
        System.out.println("Number Format: " + (obj.method_55384() != null ? obj.method_55384() : "(none)"));

        // Dump every holder that has a score in this objective
        Collection<class_9015> holders = scoreboard.method_1178();
        for (class_9015 holder : holders) {
            try {
                Object scoreObj = scoreboard.method_55430(holder, obj);
                if (scoreObj == null) continue;

                int value = extractInt(scoreObj);
                if (value != Integer.MIN_VALUE) {
                    System.out.println("  " + holder.method_5820() + " -> " + value);
                }
            } catch (Throwable ignored) {}
        }
    }

    private static void dumpScoreHolder(class_269 scoreboard, class_9015 holder, Collection<class_266> objectives) {
        System.out.println("\n--- ScoreHolder ---");
        System.out.println("Class: " + holder.getClass().getName());
        System.out.println("NameForScoreboard: " + safeCall(() -> holder.method_5820()));
        System.out.println("DisplayName: " + safeText(holder.method_5476()));
        System.out.println("StyledDisplayName: " + safeText(holder.method_55423()));

        // Dump all declared methods for ScoreHolder (for curiosity)
        Method[] methods = holder.getClass().getDeclaredMethods();
        System.out.println("Declared methods (" + methods.length + "):");
        for (Method m : methods) {
            System.out.println("  " + m.toString());
        }

        // Print scores across all objectives
        for (class_266 obj : objectives) {
            try {
                Object scoreObj = scoreboard.method_55430(holder, obj);
                if (scoreObj == null) continue;
                int value = extractInt(scoreObj);
                System.out.println("  [" + obj.method_1113() + "] " + safeText(obj.method_1114()) + " -> " + value);

                // Reflection dump of score object structure
                dumpReflection("ScoreObject for " + holder.method_5820() + "@" + obj.method_1113(), scoreObj);
            } catch (Throwable t) {
                System.out.println("  [" + obj.method_1113() + "] (error fetching score: " + t + ")");
            }
        }
    }

    static int extractInt(Object scoreObj) {
        if (scoreObj == null) return Integer.MIN_VALUE;
        Class<?> c = scoreObj.getClass();

        // 1. Try known obfuscated or mapped methods
        List<String> methodCandidates = List.of(
                "method_55397", // common obf getter
                "getScore", "getValue", "getScoreValue",
                "method_55399", "method_55398"
        );
        for (String name : methodCandidates) {
            try {
                Method m = c.getDeclaredMethod(name);
                m.setAccessible(true);
                Object result = m.invoke(scoreObj);
                if (result instanceof Number) {
                    return ((Number) result).intValue();
                }
            } catch (Throwable ignored) {}
        }

        // 2. Try public methods in superclass or interfaces
        for (Method m : c.getMethods()) {
            if (m.getReturnType() == int.class || m.getReturnType() == Integer.class) {
                try {
                    m.setAccessible(true);
                    Object result = m.invoke(scoreObj);
                    if (result instanceof Number) return ((Number) result).intValue();
                } catch (Throwable ignored) {}
            }
        }

        // 3. Try fields (some builds store score directly in a private int)
        for (Field f : c.getDeclaredFields()) {
            if (f.getType() == int.class || f.getType() == Integer.class) {
                try {
                    f.setAccessible(true);
                    return f.getInt(scoreObj);
                } catch (Throwable ignored) {}
            }
        }

        System.out.println("  [extractInt] could not extract from " + c.getName());
        return Integer.MIN_VALUE;
    }


    private static void dumpReflection(String header, Object obj) {
        if (obj == null) return;
        System.out.println("  --- Reflection dump of " + header + " ---");
        Class<?> clazz = obj.getClass();
        System.out.println("  Class: " + clazz.getName());

        for (Method m : clazz.getDeclaredMethods()) {
            try {
                m.setAccessible(true);
                Object val = null;
                if (m.getParameterCount() == 0) {
                    try {
                        val = m.invoke(obj);
                    } catch (Throwable ignored) {}
                }
                System.out.println("    " + m.getName() + "() -> " + (val != null ? val : "(no result)"));
            } catch (Throwable ignored) {}
        }
    }

    private static String safeText(class_2561 t) {
        return t == null ? "(null)" : t.getString();
    }

    private static String safeToString(Object o) {
        return o == null ? "(null)" : o.toString();
    }

    private static String safeCall(SupplierLike<String> supplier) {
        try {
            return supplier.get();
        } catch (Throwable t) {
            return "(error: " + t + ")";
        }
    }

    @FunctionalInterface
    private interface SupplierLike<T> {
        T get() throws Exception;
    }
}
