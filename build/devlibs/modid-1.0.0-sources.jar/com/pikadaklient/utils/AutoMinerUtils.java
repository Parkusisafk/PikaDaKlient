package com.pikadaklient.utils;

import com.pikadaklient.ServerCheck;
import com.pikadaklient.SidebarParser;
import com.pikadaklient.window.AutoManager;
import com.pikadaklient.window.ProgressTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.text.Text;

import java.util.concurrent.CompletableFuture;

public class AutoMinerUtils {

    private static boolean running = false;
    private static BlockPos targetCornerPos;
    private static int minY = -999;

    // Constants
    private static final int RESET_Y_THRESHOLD = 90;
    private static final int TARGET_SETUP_Y = 88;
    private static final float AIM_PITCH = 50.0f;
    private static final int DESCENT_BLOCKS = 3;
    private static final int TURN_TICKS = 6;

    // State Variables
    private enum State {
        SURFACE_CHECK,
        SETUP_SCANNING,
        SETUP_FLYING,
        SETUP_DESCEND,
        SETUP_TURN,
        LOOP_MOVE,
        LOOP_TURN,
        DESCEND,
        AFK_RESET
    }
    private static State currentState = State.SURFACE_CHECK;
    private static Direction currentDir = Direction.NORTH;
    private static float turnTargetYaw;
    private static int turnTickCounter;
    private static int turnsCompleted = 0;
    private static double descentYStart = 0;
    private static int tickelapsedforsetupmove = 0;

    public static boolean leftClick = false;

    public static void start() {
        if (MinecraftClient.getInstance().player == null) return;
        running = true;
        currentState = State.SURFACE_CHECK;
//        System.out.println("[AutoMiner] Started.");
    }

    public static void stop() {
        running = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.attackKey != null) mc.options.attackKey.setPressed(false);
        if (mc.options.leftKey != null) mc.options.leftKey.setPressed(false);
        if (mc.options.sneakKey != null) mc.options.sneakKey.setPressed(false);
        if (mc.player != null) mc.player.getAbilities().flying = false;
        AHKUtils.stopAHK();
//        System.out.println("[AutoMiner] Stopped.");
    }

    public static void tick(MinecraftClient mc) {
        if (!running || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if(isPlayerWithin(-1719,80,-22)){
            running = false;
            stop();
            AutoMinerUtils.runTransferSequenceAsync().thenAccept(success -> {
                System.out.println("Transfer success: " + success);

                if (success) {
                    // ✅ Do something if the transfer succeeded
                    start();
                } else {
                    // ❌ Die
                    System.out.println("failed!");
                }
            });
        }
        //ServerCheck.printServer();
        // --- CAPTCHA HANDLER ---

        AutoManager.getInstance().updateCurrentAction(currentState.toString());
        if (handleCaptcha(mc)) {
            mc.options.attackKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
            return;
        }

        // --- ATTACK ---
        if(currentState != State.SURFACE_CHECK &&
        currentState != State.SETUP_DESCEND &&
        currentState != State.SETUP_FLYING &&
        currentState != State.SETUP_SCANNING &&
        currentState != State.AFK_RESET) {
            //mc.options.attackKey.setPressed(true);
            //performAttack(mc);
        }
        // --- STATE MACHINE ---
        switch (currentState) {

            case SURFACE_CHECK:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.player.getY() >= RESET_Y_THRESHOLD) {
                    mc.player.getAbilities().flying = true;
                    mc.player.getAbilities().setFlySpeed(0.05f);
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_SCANNING;
                    minY = detectMinY(mc);
//                    //System.out.println("[AutoMiner] Surface detected. MinY=" + minY);
                } else if (mc.player.getY() <= 19) { //hardcoded
                    currentState = State.AFK_RESET;
//                    //System.out.println("[AutoMiner] AFK reset triggered.");
                } else {
                    tickelapsedforsetupmove = 0;
                    currentState = State.LOOP_MOVE;
                }
                break;

            case SETUP_SCANNING:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (findCorner(mc)) {
//                    //System.out.println("[AutoMiner] Corner found at " + targetCornerPos);
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_FLYING;
                }
                mc.options.leftKey.setPressed(false);
                mc.options.sneakKey.setPressed(false);
                break;

            case SETUP_FLYING:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 1000){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }



                if (!mc.player.getAbilities().flying) {
                    // Simulate a jump (spacebar press)
                    mc.options.jumpKey.setPressed(true);

                    // Give Minecraft a tick to register the jump
                    // (release immediately so it doesn't spam jump)
                    mc.options.jumpKey.setPressed(false);

                    // Enable flying explicitly
                    mc.player.getAbilities().flying = true;
                    mc.player.getAbilities().setFlySpeed(0.05f);

//                    //System.out.println("[AutoMiner] Activated flying mode.");
                }
                BlockPos pos = targetCornerPos;
                Vec3d targetCenter = new Vec3d(
                        pos.getX() + 0.5, // center X
                        mc.player.getY(), // current Y
                        pos.getZ() + 0.5  // center Z
                );                moveTowards(mc, targetCenter, true, false);
//                //System.out.println("[AutoMiner] Flying to corner: currentPos=" + mc.player.getPos());

                if (mc.player.getPos().distanceTo(targetCenter) < 0.25) {
                    mc.player.setVelocity(Vec3d.ZERO);
                    currentState = State.SETUP_DESCEND;
                    tickelapsedforsetupmove = 0;
//                    //System.out.println("[AutoMiner] Reached corner, descending...");
                }
                break;

            case SETUP_DESCEND:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                mc.options.leftKey.setPressed(false);
                mc.options.sneakKey.setPressed(true);
                mc.player.setPitch(AIM_PITCH);

                if (mc.player.getY() <= TARGET_SETUP_Y - 0.5) {
                    mc.options.sneakKey.setPressed(false);
                    mc.player.setVelocity(Vec3d.ZERO);
                    turnsCompleted = 0;
                    turnTickCounter = 0;
                    tickelapsedforsetupmove = 0;
                    currentState = State.SETUP_TURN;
//                    //System.out.println("[AutoMiner] Setup descend complete. Start mining loop.");
                }
                break;

            case SETUP_TURN:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                // Ensure no stray keys are pressed
                mc.options.leftKey.setPressed(false);
                mc.options.sneakKey.setPressed(false);

                BlockPos playerPos = mc.player.getBlockPos();
                Direction chosenDir = null;

                // Find the open direction: the one after two consecutive bedrock blocks clockwise
                for (Direction dir : Direction.Type.HORIZONTAL) {
                    Direction clockwise1 = dir;
                    Direction clockwise2 = dir.rotateYClockwise();

                    boolean b1 = isBedrock(mc.world.getBlockState(playerPos.offset(clockwise1)));
                    boolean b2 = isBedrock(mc.world.getBlockState(playerPos.offset(clockwise2)));

                    if (b1 && b2) {
                        // The next clockwise direction is the tunnel direction
                        chosenDir = clockwise2.rotateYClockwise();
                        break;
                    }
                }

                if (chosenDir != null) {
                    currentDir = chosenDir;

                    // Look into the mine (perpendicular to wall, inward)
                    Direction intoMine = currentDir.rotateYCounterclockwise();
                    float baseYaw = RotationUtils.dirToYaw(intoMine);

                    // Apply small left bias
                    float bias = 15.0f; // adjust as needed
                    float targetYaw = (baseYaw + 85) % 360.0f; //HARDCODED GOES HARD AF


                    // Smoothly turn toward target yaw
                    RotationUtils.smoothTurnYaw(mc, targetYaw, 10.0f);

                    // Look downward at ~30°
                    mc.player.setPitch(30.0f);

                    // When close enough to target yaw, move to LOOP_MOVE
                    if (Math.abs(RotationUtils.wrapDegrees(targetYaw - mc.player.getYaw())) < 2.0f) {
//                        System.out.println("[AutoMiner] Setup turn complete. Facing " + currentDir);
                        tickelapsedforsetupmove = 0;
                        currentState = State.LOOP_MOVE;
                    }
                } else {
//                    System.out.println("[AutoMiner] Could not determine initial tunnel direction!");
                }
                break;

            case LOOP_MOVE:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.player.getY() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.player.getY() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    mc.options.leftKey.setPressed(true);
                    mc.player.setPitch(AIM_PITCH);
                    //mc.player.setYaw();
                    // Check left wall
                    BlockPos playerPos1 = mc.player.getBlockPos();
                    Direction moveDir = currentDir; // direction we are flying along
                    Direction lookDir2 = moveDir.rotateYClockwise(); // 90° clockwise from movement = facing inward


// Block behind (wall you’re hugging)
                    BlockPos backPos = playerPos1.offset(lookDir2);

// Block to the left (corner detection)
                    BlockPos leftPos = playerPos1.offset(moveDir.rotateYCounterclockwise());

// Debugging
                    BlockState backState = mc.world.getBlockState(backPos);
                    BlockState leftState = mc.world.getBlockState(leftPos);

//                    System.out.println("[AutoMiner] Back block: " + backPos + " Type: " + backState.getBlock().getTranslationKey());
//                    System.out.println("[AutoMiner] Left block: " + leftPos + " Type: " + leftState.getBlock().getTranslationKey());

// Turning condition: bedrock to the left
                    if (isBedrock(leftState)) {
//                        System.out.println("[AutoMiner] Bedrock detected on left at " + leftPos + ", turning...");
                        mc.options.leftKey.setPressed(false);
                        turnTargetYaw = mc.player.getYaw() + 90.0f;
                        turnTargetYaw %= 360;
                        turnTickCounter = 0;
                        tickelapsedforsetupmove = 0;
                        currentState = State.LOOP_TURN;
                    }
                }
                break;

            case LOOP_TURN:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.player.getY() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.player.getY() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    float currentYaw = mc.player.getYaw();
                    float yawDiff = turnTargetYaw - currentYaw;
                    while (yawDiff < -180) yawDiff += 360;
                    while (yawDiff > 180) yawDiff -= 360;

                    float turnAmount = yawDiff / (TURN_TICKS - turnTickCounter);
                    mc.player.setYaw(currentYaw + turnAmount);
                    turnTickCounter++;

                    if (turnTickCounter >= TURN_TICKS) {
                        turnsCompleted++;
                        currentDir = currentDir.rotateYClockwise();
//                        System.out.println("[AutoMiner] Turn completed. Turns done: " + turnsCompleted);
                        if (turnsCompleted >= 2) { //hardcoded
                            tickelapsedforsetupmove = 0;
                            currentState = State.DESCEND;
                            descentYStart = mc.player.getY();
//                            System.out.println("[AutoMiner] Completed loop, starting descent.");
                        } else {
                            tickelapsedforsetupmove = 0;
                            currentState = State.LOOP_MOVE;
                        }
                    }
                    mc.options.leftKey.setPressed(false);
                }
                break;

            case DESCEND:
                if(!leftClick){
                    leftClick = true;
                    AHKUtils.startAHK();
                }
                tickelapsedforsetupmove++;
                if(tickelapsedforsetupmove > 300){
                    currentState = State.AFK_RESET;
                    tickelapsedforsetupmove = 0;
                    break;
                }
                if (mc.player.getY() <= 20){
                    tickelapsedforsetupmove = 0;
                    currentState = State.AFK_RESET;
                } else if (mc.player.getY() >=90){
                    tickelapsedforsetupmove = 0;
                    currentState = State.SURFACE_CHECK;
                } else {
                    mc.options.leftKey.setPressed(false);
                    mc.options.sneakKey.setPressed(true);

                    if (descentYStart == 0) descentYStart = mc.player.getY();

                    if (mc.player.getY() <= descentYStart - 3) {
                        mc.options.sneakKey.setPressed(false);
//                        System.out.println("[AutoMiner] Descend complete. CurrentY=" + mc.player.getY());
                        if (mc.player.getY() <= 20) {
                            tickelapsedforsetupmove = 0;
                            currentState = State.AFK_RESET;
//                            System.out.println("[AutoMiner] Reached bottom. AFK reset.");
                        } else {
                            turnsCompleted = 0;
                            tickelapsedforsetupmove = 0;
                            currentState = State.LOOP_MOVE;
                            descentYStart = 0;
//                            System.out.println("[AutoMiner] Starting next mining loop.");
                        }
                    }
                }
                break;

            case AFK_RESET:
                if(leftClick){
                    leftClick = false;
                    AHKUtils.stopAHK();
                }
                //mc.options.attackKey.setPressed(true);
                mc.options.leftKey.setPressed(false);
                mc.options.sneakKey.setPressed(false);
                mc.player.getAbilities().flying = false;
                if (mc.player.getY() >= RESET_Y_THRESHOLD) {
                    currentState = State.SURFACE_CHECK;
                }
                break;
        }
    }

    // ---------------- Helper Methods ----------------


    private static void performAttack(MinecraftClient mc) {
//        if (mc.player == null || mc.interactionManager == null || mc.world == null) return;
//
//        HitResult hit = mc.crosshairTarget;
//        // Keep the attack key pressed. This is required for the client to think it's still mining.
//        mc.options.attackKey.setPressed(true);
//
//        if (hit instanceof BlockHitResult blockHit) {
//            BlockPos pos = blockHit.getBlockPos();
//            Direction side = blockHit.getSide();
//
//            // --- 1. ESTABLISH MINING STATE ---
//            // Call the standard method once per block to send the initial START_DESTROY_BLOCK
//            // and tell the client's interaction manager which block is being broken.
//            // It does not hurt to call this every tick if the block hasn't changed.
//            mc.interactionManager.attackBlock(pos, side);
//
//            // --- 2. INSTABREAK SPAM (The core of InstantRebreak) ---
//            // Aggressively send the STOP_DESTROY_BLOCK packet every tick.
//            // This forces the server to check for block break completion, which is instant
//            // if the player has high Haste/Efficiency.
//            mc.interactionManager.sendSequencedPacket(mc.world, s ->
//                    new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, pos, side, s)
//            );
//
//            // --- 3. VISUAL/SWING ---
//            // You only need to call mc.player.swingHand(Hand.MAIN_HAND) once here.
//            // No need for a separate HandSwingC2SPacket unless you wanted to prevent the visual swing.
//            mc.player.swingHand(Hand.MAIN_HAND);
//e
//        } else if (mc.targetedEntity != null) {
//            // Attack entities if they are the target.
//            mc.interactionManager.attackEntity(mc.player, mc.targetedEntity);
//            mc.player.swingHand(Hand.MAIN_HAND);
//        }
    }


    private static Direction findInitialDir(BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Check all 4 cardinal directions around player
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockState state = mc.world.getBlockState(pos.offset(dir));
//            System.out.println("[AutoMiner] Check " + dir + ": " + state.getBlock().getTranslationKey());
        }

        // Loop through clockwise order
        for (Direction dir : Direction.Type.HORIZONTAL) {
            Direction cw1 = dir.rotateYClockwise();
            Direction cw2 = cw1.rotateYClockwise();

            boolean firstBedrock = isBedrock(mc.world.getBlockState(pos.offset(dir)));
            boolean secondBedrock = isBedrock(mc.world.getBlockState(pos.offset(cw1)));
            boolean thirdOpen = !isBedrock(mc.world.getBlockState(pos.offset(cw2)));

            if (firstBedrock && secondBedrock && thirdOpen) {
//                System.out.println("[AutoMiner] Initial move dir found: " + cw2);
                return cw2; // this is the correct currentDir
            }
        }

//        System.out.println("[AutoMiner] Failed to find initial move dir, defaulting to NORTH");
        return Direction.NORTH; // fallback
    }

    private static boolean findCorner(MinecraftClient mc) {
        BlockPos playerPos = mc.player.getBlockPos();

        // Define the hardcoded blacklisted coordinate
        final int BLACKLIST_X = 67055;
        final int BLACKLIST_Z = 233104;

        for (int x = playerPos.getX() - 50; x < playerPos.getX() + 50; x++) {
            for (int z = playerPos.getZ() - 50; z < playerPos.getZ() + 50; z++) {

                // NOTE: TARGET_SETUP_Y must be defined outside this method (e.g., as a static final field)
                BlockPos pos = new BlockPos(x, TARGET_SETUP_Y, z);

                // --- BLACKLIST CHECK ---
                if (x == BLACKLIST_X || z == BLACKLIST_Z) {
//                    System.out.println("[AutoMiner] Skipping blacklisted corner: " + pos + " (Hardcoded exclusion)");
                    continue; // Skip the rest of the loop iteration for this position
                }
                // -----------------------

                BlockState state = mc.world.getBlockState(pos);

                if (state.isAir()) {
                    int airCount = 0, bedrockCount = 0;

                    for (Direction dir : Direction.Type.HORIZONTAL) {
                        BlockState adj = mc.world.getBlockState(pos.offset(dir));
                        if (adj.isAir()) airCount++;
                        else if (isBedrock(adj)) bedrockCount++; // Assuming isBedrock is defined elsewhere
                    }

                    // If this position has exactly two air blocks and two bedrock blocks (a perfect corner)
                    if (airCount == 2 && bedrockCount == 2) {
                        targetCornerPos = pos;
//                        System.out.println("[AutoMiner] Corner candidate found: " + pos);

                        // Determine the mining direction (opposite the nearest bedrock wall)
                        for (Direction dir : Direction.Type.HORIZONTAL) {
                            if (isBedrock(mc.world.getBlockState(pos.offset(dir)))) {
                                currentDir = dir.getOpposite();
                                break;
                            }
                        }
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private static void moveTowards(MinecraftClient mc, Vec3d target, boolean flyXZ, boolean flyY) {
        Vec3d dir = target.subtract(mc.player.getPos());
        double distance = dir.length();
        if (distance < 0.1) {
            mc.player.setVelocity(Vec3d.ZERO);
            return;
        }
        double speed = mc.player.getAbilities().getFlySpeed() * 5.0;
        Vec3d movementVec = new Vec3d(flyXZ ? dir.getX() : 0,
                flyY ? dir.getY() : 0,
                flyXZ ? dir.getZ() : 0).normalize().multiply(speed);
        mc.player.setVelocity(movementVec);
        double yawAngle = Math.toDegrees(Math.atan2(-dir.getX(), dir.getZ()));
        mc.player.setYaw((float) yawAngle);
        mc.player.setPitch(0.0f);
    }
    private static int detectMinY(MinecraftClient mc) {
        int y = mc.player.getBlockPos().getY();
        while (y > mc.world.getBottomY()) {
            if (isBedrock(mc.world.getBlockState(new BlockPos((int) mc.player.getX(), y - 1, (int) mc.player.getZ())))) {
                return y;
            }
            y--;
        }
        return mc.world.getBottomY();
    }

    private static boolean handleCaptcha(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof GenericContainerScreen screen)) {
            return false;
        }

        Slot targetSlot = null;

//        System.out.println("--- CAPTCHA ITEM DEBUG START ---");

        for (Slot slot : screen.getScreenHandler().slots) {
            ItemStack stack = slot.getStack();
            if (stack.isEmpty()) continue;

            String plainName = stack.getName().getString().toLowerCase();
            String itemString = stack.getItem().toString();

            boolean nameMatch = plainName.contains("click") && (plainName.contains("confirm") || plainName.contains("continue"));
            boolean isFiller = itemString.contains("stained_glass_pane");
            boolean isMatch = nameMatch && !isFiller;

            System.out.printf(
                    "[SLOT %d] Item: %s | Name: '%s' | NameMatch: %b | IsFiller: %b | Final Match: %b%n",
                    slot.id, itemString, plainName, nameMatch, isFiller, isMatch
            );

            if (isMatch) {
                targetSlot = slot;
                break;
            }
        }

//        System.out.println("--- CAPTCHA ITEM DEBUG END ---");

        if (targetSlot != null) {
            System.out.printf("[CAPTCHA SUCCESS] Clicking Slot ID: %d%n", targetSlot.id);
            clickSlot(screen, targetSlot.id, false); // use helper, left-click
        } else {
//            System.out.println("[CAPTCHA FAIL] No clickable item found.");
        }

        return targetSlot != null;
    }
    private static void clickSlot(GenericContainerScreen screen, int slot, boolean right) {
         MinecraftClient mc = MinecraftClient.getInstance();
         mc.interactionManager.clickSlot(
                screen.getScreenHandler().syncId,
                slot,
                right ? 1 : 0,
                SlotActionType.PICKUP,
                mc.player
        );
    }

    private static boolean isBedrock(BlockState state) {
        return state.getBlock() == Blocks.BEDROCK;
    }
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static boolean isPlayerWithin(int targetX, int targetY, int targetZ) {
        if (mc.player == null) return false;

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        double dx = px - targetX;
        double dy = py - targetY;
        double dz = pz - targetZ;

        // Euclidean distance
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

        return distance <= 10.0;
    }

    /**
     * Runs the transfer routine once asynchronously, returns CompletableFuture<Boolean>.
     */
    public static CompletableFuture<Boolean> runTransferSequenceAsync() {
        CompletableFuture<Boolean> result = new CompletableFuture<>();

        new Thread(() -> {
            ClientPlayerEntity player = mc.player;
            ClientWorld world = mc.world;
            if (player == null || world == null) {
                result.complete(false);
                return;
            }

            try {
                Thread.sleep(2000);

                // Step 1: Select 5th slot and check for compass
                int slotIndex = 4;
                mc.execute(() -> player.getInventory().setSelectedSlot(slotIndex));

                Thread.sleep(100); // small delay for slot update

                ItemStack stack = player.getMainHandStack();
                if (stack.isEmpty() || stack.getItem() != Items.COMPASS) {
                    result.complete(false);
                    return;
                }

                // Step 2: Right-click the compass
                mc.execute(() -> mc.interactionManager.interactItem(player, Hand.MAIN_HAND));

                // Step 3: Wait up to 5s for chest GUI
                if (!waitForScreen(GenericContainerScreen.class, 5000)) {
                    result.complete(false);
                    return;
                }
                Thread.sleep(2000);
                // Step 4: Check for iron bars
                GenericContainerScreen chest = (GenericContainerScreen) mc.currentScreen;
                int size = chest.getScreenHandler().getInventory().size();
                if (size < 54) {
                    result.complete(false);
                    return;
                }

                int ironBarSlot = -1;
                for (int i = 0; i < size; i++) {
                    ItemStack item = chest.getScreenHandler().getInventory().getStack(i);
                    if (!item.isEmpty() && item.getItem() == Items.IRON_BARS) {
                        ironBarSlot = i;
                        break;
                    }
                }

                if (ironBarSlot == -1) {
                    result.complete(false);
                    return;
                }

                // Step 5: Click iron bars
                final int barSlot = ironBarSlot;
                mc.execute(() -> mc.interactionManager.clickSlot(
                        chest.getScreenHandler().syncId,
                        barSlot, 0, SlotActionType.PICKUP, player
                ));

                // Step 6: Wait 10s for transfer
                Thread.sleep(10000);

                // Step 7: Walk forward until bedrock or 15s timeout
                press(mc.options.forwardKey, true);
                boolean foundBedrock = waitForBedrockBelow(15000);
                press(mc.options.forwardKey, false);
                if (!foundBedrock) {
                    result.complete(false);
                    return;
                }

                // Step 8: Jump + walk 1s
                press(mc.options.jumpKey, true);
                press(mc.options.forwardKey, true);
                Thread.sleep(1000);
                press(mc.options.jumpKey, false);
                press(mc.options.forwardKey, false);

                // Step 9: Check coordinates
                BlockPos target = new BlockPos(67095, 90, 233042);
                BlockPos current = player.getBlockPos();
                boolean within10 = current.getSquaredDistance(target) <= 100.0;
                result.complete(true); //hardcoded

            } catch (Exception e) {
                result.complete(false);
            }
        }, "AutoSubserverThread").start();

        return result;
    }

    // === Helper methods ===

    private static boolean waitForScreen(Class<? extends Screen> screenType, long timeoutMs) {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (mc.currentScreen != null && screenType.isInstance(mc.currentScreen))
                return true;
            try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        }
        return false;
    }

    private static boolean waitForBedrockBelow(long timeoutMs) {
        long start = System.currentTimeMillis();
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (mc.player == null || mc.world == null) return false;
            BlockPos below = mc.player.getBlockPos().down();
            if (mc.world.getBlockState(below).getBlock() == Blocks.BEDROCK)
                return true;
            try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        }
        return false;
    }

    private static void press(KeyBinding key, boolean down) {
        mc.execute(() -> key.setPressed(down));
    }

    }
